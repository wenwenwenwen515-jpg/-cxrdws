# SafeInstallLogicDemo

这是一个正规教学演示，用来理解“为什么卸载一个 App 后，另一个包还在”。

## 包结构

- mainapp：主包，包名 `com.example.installlogic.main`
- helperapp：副包，包名 `com.example.installlogic.helper`

## 安装逻辑

1. GitHub Actions 先编译 `helperapp`。
2. 把生成的 `helperapp-debug.apk` 复制到 `mainapp/src/main/assets/helper-demo.apk`。
3. 再编译 `mainapp`。
4. 安装主包后，点击“安装副包演示”。
5. 主包把 assets 里的副包 APK 复制到缓存目录。
6. 主包调用系统安装器，用户手动确认安装副包。
7. 副包安装后就是独立应用。
8. 卸载主包，不会自动卸载副包。

## 注意

这是教学版，不包含静默安装、不包含隐藏图标、不包含卸载后偷偷驻留。
两个包都可以在系统应用管理里看到并单独卸载。
