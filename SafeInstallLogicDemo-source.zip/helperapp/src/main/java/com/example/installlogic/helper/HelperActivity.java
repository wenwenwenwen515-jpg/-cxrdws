package com.example.installlogic.helper;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HelperActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(20), dp(45), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("安装逻辑副包");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText(
                "我是副包，也是一个独立 APK。\n\n" +
                "你可以测试：\n" +
                "1. 先安装主包。\n" +
                "2. 从主包里手动安装我。\n" +
                "3. 再卸载主包。\n" +
                "4. 我仍然会留在系统里。\n\n" +
                "原因：安卓把我们当成两个不同包名的 App。\n" +
                "卸载一个包，不会自动卸载另一个包。\n\n" +
                "我不是隐藏包，也不是残留木马；你可以在设置 → 应用管理里单独卸载我。"
        );
        info.setTextSize(16);
        info.setPadding(0, dp(22), 0, 0);
        box.addView(info, new LinearLayout.LayoutParams(-1, -2));

        setContentView(box);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
