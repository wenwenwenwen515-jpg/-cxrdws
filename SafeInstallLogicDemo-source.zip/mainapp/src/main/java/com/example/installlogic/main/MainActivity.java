package com.example.installlogic.main;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String HELPER_PACKAGE = "com.example.installlogic.helper";
    private static final String HELPER_ASSET = "helper-demo.apk";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(20), dp(35), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("安装逻辑主包");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText(
                "这是正规教学演示：\n\n" +
                "1. 主包内置一个副包 APK 文件。\n" +
                "2. 点击按钮后，主包复制副包到缓存。\n" +
                "3. 再调用系统安装器，让用户手动确认安装。\n" +
                "4. 副包安装后就是独立 App。\n" +
                "5. 以后卸载主包，副包不会自动卸载。\n\n" +
                "这不是静默安装，也不是隐藏残留。两个包都能在应用管理里看到并单独卸载。"
        );
        info.setTextSize(15);
        info.setPadding(0, dp(20), 0, dp(20));
        box.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button install = new Button(this);
        install.setText("安装副包演示");
        install.setOnClickListener(v -> installHelperPackage());
        box.addView(install, new LinearLayout.LayoutParams(-1, dp(52)));

        Button open = new Button(this);
        open.setText("打开副包");
        open.setOnClickListener(v -> openHelperPackage());
        box.addView(open, new LinearLayout.LayoutParams(-1, dp(52)));

        Button check = new Button(this);
        check.setText("检查副包是否已安装");
        check.setOnClickListener(v -> {
            boolean installed = isPackageInstalled(HELPER_PACKAGE);
            Toast.makeText(this, installed ? "副包已安装" : "副包未安装", Toast.LENGTH_SHORT).show();
        });
        box.addView(check, new LinearLayout.LayoutParams(-1, dp(52)));

        setContentView(box);
    }

    private void installHelperPackage() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getPackageManager().canRequestPackageInstalls()) {
                Toast.makeText(this, "请先允许本应用安装未知来源应用，然后返回再点一次安装。", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            }

            File apk = new File(getCacheDir(), HELPER_ASSET);
            copyAssetToFile(HELPER_ASSET, apk);

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);

            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "安装演示失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void copyAssetToFile(String assetName, File outFile) throws Exception {
        InputStream inputStream = getAssets().open(assetName);
        FileOutputStream outputStream = new FileOutputStream(outFile);
        byte[] buffer = new byte[8192];
        int len;
        while ((len = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, len);
        }
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

    private void openHelperPackage() {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(HELPER_PACKAGE);
            if (intent == null) {
                Toast.makeText(this, "副包还没安装", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "打不开副包", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPackageInstalled(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
