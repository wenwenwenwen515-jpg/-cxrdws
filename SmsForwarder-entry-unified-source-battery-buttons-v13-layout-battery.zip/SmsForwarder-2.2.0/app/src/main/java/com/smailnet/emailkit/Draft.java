package com.smailnet.emailkit;

public class Draft {
    public String nickname;
    public String to;
    public String subject;
    public String text;

    public Draft setNickname(String nickname) { this.nickname = nickname; return this; }
    public Draft setTo(String to) { this.to = to; return this; }
    public Draft setSubject(String subject) { this.subject = subject; return this; }
    public Draft setText(String text) { this.text = text; return this; }
}
