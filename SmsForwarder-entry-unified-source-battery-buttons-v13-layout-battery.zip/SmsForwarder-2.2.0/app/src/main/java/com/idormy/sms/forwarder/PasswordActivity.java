package com.idormy.sms.forwarder;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PasswordActivity extends AppCompatActivity {
    private static final String PASSWORD_FIRST = "1234";
    private static final String PASSWORD_AFTER = "1029";
    private static final String PREF_NAME = "engine_password_state";
    private static final String KEY_SUCCESS_COUNT = "success_count";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#111111"));
        buildLayout();
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(28), dp(92), dp(28), dp(28));
        root.setBackgroundColor(Color.parseColor("#111111"));

        TextView title = new TextView(this);
        title.setText("工程模式");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("请输入工程码进入调试模式");
        hint.setTextColor(Color.parseColor("#CFCFCF"));
        hint.setTextSize(15);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.setMargins(0, dp(12), 0, dp(28));
        root.addView(hint, hintLp);

        EditText input = new EditText(this);
        input.setHint("工程码");
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.parseColor("#888888"));
        input.setTextSize(22);
        input.setGravity(Gravity.CENTER);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(Color.parseColor("#2C2C2E"));
        inputBg.setCornerRadius(dp(16));
        input.setBackground(inputBg);
        input.setPadding(dp(16), 0, dp(16), 0);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, dp(58));
        inputLp.setMargins(0, 0, 0, dp(18));
        root.addView(input, inputLp);

        Button enter = new Button(this);
        enter.setText("进入");
        enter.setAllCaps(false);
        enter.setTextSize(20);
        enter.setTypeface(Typeface.DEFAULT_BOLD);
        enter.setTextColor(Color.WHITE);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#34C759"));
        btnBg.setCornerRadius(dp(18));
        enter.setBackground(btnBg);
        root.addView(enter, new LinearLayout.LayoutParams(-1, dp(58)));

        enter.setOnClickListener(v -> {
            String code = input.getText().toString().trim();
            SharedPreferences sp = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
            int successCount = sp.getInt(KEY_SUCCESS_COUNT, 0);
            String currentPassword = successCount >= 3 ? PASSWORD_AFTER : PASSWORD_FIRST;
            if (currentPassword.equals(code)) {
                if (PASSWORD_FIRST.equals(code)) {
                    sp.edit().putInt(KEY_SUCCESS_COUNT, successCount + 1).apply();
                }
                Intent mainIntent = new Intent(this, MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(mainIntent);
                finish();
            } else {
                Toast.makeText(this, "工程码错误", Toast.LENGTH_SHORT).show();
            }
        });

        setContentView(root);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
