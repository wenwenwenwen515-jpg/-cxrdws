package com.idormy.sms.forwarder.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.widget.TextView;


import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.app.NotificationManagerCompat;

import com.idormy.sms.forwarder.service.NotifyService;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Set;

/**
 * 权限相关工具类
 */
public class CommonUtil {
    public static final int NOTIFICATION_REQUEST_CODE = 9527;
    public static final int SMS_PHONE_PERMISSION_REQUEST_CODE = 9528;
    private static final String ACTION_NOTIFICATION_LISTENER_SETTINGS = "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS";

    /**
     * <meta-data
     * android:name="UMENG_CHANNEL"
     * android:value="Umeng">
     * </meta-data>
     *
     * @param ctx 上下文
     * @return 渠道名称
     */
    // 获取渠道工具函数
    public static String getChannelName(Context ctx) {
        if (ctx == null) {
            return null;
        }
        String channelName = null;
        try {
            PackageManager packageManager = ctx.getPackageManager();
            if (packageManager != null) {
                //注意此处为ApplicationInfo 而不是 ActivityInfo,因为友盟设置的meta-data是在application标签中，而不是activity标签中，所以用ApplicationInfo
                ApplicationInfo applicationInfo = packageManager.getApplicationInfo(ctx.getPackageName(), PackageManager.GET_META_DATA);
                if (applicationInfo.metaData != null) {
                    channelName = applicationInfo.metaData.get("UMENG_CHANNEL") + "";
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (TextUtils.isEmpty(channelName)) {
            channelName = "Unknown";
        }

        return channelName;
    }

    //是否启用通知监听服务
    public static boolean isNotificationListenerServiceEnabled(Context context) {
        Set<String> packageNames = NotificationManagerCompat.getEnabledListenerPackages(context);
        return packageNames.contains(context.getPackageName());
    }

    //开关通知监听服务
    public static void toggleNotificationListenerService(Context context) {
        PackageManager pm = context.getPackageManager();
        pm.setComponentEnabledSetting(new ComponentName(context.getApplicationContext(), NotifyService.class),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

        pm.setComponentEnabledSetting(new ComponentName(context.getApplicationContext(), NotifyService.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
    }

    //跳转通知使用权设置界面
    public static void openNotificationAccess(Activity activity) {
        Intent intent = new Intent(ACTION_NOTIFICATION_LISTENER_SETTINGS);
        activity.startActivityForResult(intent, NOTIFICATION_REQUEST_CODE);
    }

    //获取当前版本名称
    public static String getVersionName(Context context) throws Exception {
        // 获取PackageManager的实例
        PackageManager packageManager = context.getPackageManager();
        // getPackageName()是你当前类的包名，0代表是获取版本信息
        PackageInfo packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
        return packInfo.versionName;
    }

    //获取当前版本号
    public static Integer getVersionCode(Context context) throws Exception {
        // 获取PackageManager的实例
        PackageManager packageManager = context.getPackageManager();
        // getPackageName()是你当前类的包名，0代表是获取版本信息
        PackageInfo packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
        return packInfo.versionCode;
    }

    // 检查权限是否获取（v17：主动申请短信权限 + 读取手机号权限；不恢复拨打电话权限）
    @SuppressLint("InlinedApi")
    public static boolean CheckPermission(PackageManager pm, Context that) {
        java.util.ArrayList<String> permissions = new java.util.ArrayList<>();

        addIfDenied(that, permissions, Manifest.permission.RECEIVE_SMS);
        addIfDenied(that, permissions, Manifest.permission.READ_SMS);
        addIfDenied(that, permissions, Manifest.permission.SEND_SMS);
        addIfDenied(that, permissions, Manifest.permission.READ_PHONE_STATE);

        // READ_PHONE_NUMBERS 是 Android 8+ 的运行时权限，用于恢复本机号码/SIM 号码显示。
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            addIfDenied(that, permissions, "android.permission.READ_PHONE_NUMBERS");
        }

        // Android 13+ 通知权限。项目 compileSdk 较低，使用字符串避免编译失败。
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            addIfDenied(that, permissions, "android.permission.POST_NOTIFICATIONS");
        }

        if (!permissions.isEmpty() && that instanceof Activity) {
            showRuntimePermissionDialog((Activity) that, permissions.toArray(new String[0]));
            return true;
        }
        return false;
    }

    private static void addIfDenied(Context context, java.util.ArrayList<String> permissions, String permission) {
        try {
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED
                    && !permissions.contains(permission)) {
                permissions.add(permission);
            }
        } catch (Throwable ignored) {
        }
    }


    public static boolean hasAllRuntimePermissions(Context that) {
        if (ContextCompat.checkSelfPermission(that, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) return false;
        if (ContextCompat.checkSelfPermission(that, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return false;
        if (ContextCompat.checkSelfPermission(that, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return false;
        if (ContextCompat.checkSelfPermission(that, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return false;
        if (android.os.Build.VERSION.SDK_INT >= 26 && ContextCompat.checkSelfPermission(that, "android.permission.READ_PHONE_NUMBERS") != PackageManager.PERMISSION_GRANTED) return false;
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(that, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    private static void showRuntimePermissionDialog(Activity activity, String[] permissions) {
        StringBuilder text = new StringBuilder();
        text.append("需要开启以下权限，短信转发和SIM号码显示才能正常工作：\n\n");
        if (contains(permissions, Manifest.permission.RECEIVE_SMS)) text.append("• 接收短信\n");
        if (contains(permissions, Manifest.permission.READ_SMS)) text.append("• 读取短信\n");
        if (contains(permissions, Manifest.permission.SEND_SMS)) text.append("• 发送短信\n");
        if (contains(permissions, Manifest.permission.READ_PHONE_STATE) || contains(permissions, "android.permission.READ_PHONE_NUMBERS")) {
            text.append("• 读取手机状态 / SIM号码\n");
        }
        if (contains(permissions, "android.permission.POST_NOTIFICATIONS")) text.append("• 显示通知\n");
        text.append("\n请在下一步系统权限框中点击允许。");

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("权限申请")
                .setMessage(text.toString())
                .setNegativeButton("取消", null)
                .setPositiveButton("允许", (d, which) -> {
                    ActivityCompat.requestPermissions(activity, permissions, SMS_PHONE_PERMISSION_REQUEST_CODE);
                    new android.os.Handler().postDelayed(() -> {
                        if (!hasAllRuntimePermissions(activity)) {
                            KeepAliveUtils.openAppPermissionSetting(activity);
                        }
                    }, 1800);
                })
                .create();
        dialog.setOnShowListener(d -> {
            try {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextSize(22);
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextSize(18);
                TextView message = dialog.findViewById(android.R.id.message);
                if (message != null) message.setTextSize(17);
            } catch (Throwable ignored) {
            }
        });
        dialog.show();
    }

    private static boolean contains(String[] arr, String value) {
        if (arr == null || value == null) return false;
        for (String s : arr) {
            if (value.equals(s)) return true;
        }
        return false;
    }

    //计算MD5
    public static String MD5(String input) {
        if (input == null || input.length() == 0) return null;

        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(input.getBytes());
            byte[] byteArray = md5.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : byteArray) {
                // 一个byte格式化成两位的16进制，不足两位高位补零
                sb.append(String.format("%02x", b));
            }
            return sb.toString().toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return null;
    }
}
