package com.idormy.sms.forwarder.sender;

import android.os.Handler;
import android.util.Log;

import com.idormy.sms.forwarder.utils.LogUtil;
import com.idormy.sms.forwarder.utils.SettingUtil;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SenderBarkMsg extends SenderBaseMsg {
    static final String TAG = "SenderBarkMsg";

    public static void sendMsg(final long logId, final Handler handError, String barkServer, String barkIcon, String from, String content, String groupName) throws Exception {
        if (barkServer == null || barkServer.trim().isEmpty()) {
            return;
        }

        final String requestUrl = buildUrl(barkServer, barkIcon, from, content, groupName);
        Log.i(TAG, "requestUrl:" + requestUrl);

        new Thread(() -> requestWithRetry(logId, handError, requestUrl), "sender-bark").start();
    }

    private static String buildUrl(String barkServer, String barkIcon, String from, String content, String groupName) throws Exception {
        String safeFrom = from == null ? "" : from;
        String safeContent = content == null ? "" : content;
        String safeGroup = groupName == null ? "" : groupName;

        safeContent = safeContent.replaceFirst("^" + Pattern.quote(safeFrom) + "(.*)", "").trim();

        barkServer = barkServer.trim();
        if (!barkServer.endsWith("/")) {
            barkServer += "/";
        }

        StringBuilder url = new StringBuilder();
        url.append(barkServer)
                .append(encode(safeFrom))
                .append("/")
                .append(encode(safeContent))
                .append("?isArchive=1")
                .append("&group=").append(encode(safeGroup));

        if (barkIcon != null && !barkIcon.isEmpty()) {
            url.append("&icon=").append(encode(barkIcon));
        }

        if (safeContent.contains("验证码") || safeContent.contains("动态密码")) {
            Matcher matcher = Pattern.compile("(\\d{4,6})").matcher(safeContent);
            if (matcher.find()) {
                url.append("&automaticallyCopy=1&copy=").append(encode(matcher.group()));
            }
        }
        return url.toString();
    }

    private static String encode(String value) throws Exception {
        return URLEncoder.encode(value == null ? "" : value, "UTF-8").replace("+", "%20");
    }

    private static void requestWithRetry(long logId, Handler handError, String requestUrl) {
        int[] delays = new int[]{0,
                SettingUtil.getRetryDelayTime(1),
                SettingUtil.getRetryDelayTime(2),
                SettingUtil.getRetryDelayTime(3),
                SettingUtil.getRetryDelayTime(4),
                SettingUtil.getRetryDelayTime(5)};

        Exception lastError = null;
        for (int attempt = 0; attempt < delays.length; attempt++) {
            try {
                if (attempt > 0) {
                    int delay = delays[attempt];
                    Toast(handError, TAG, "请求接口异常，" + delay + "秒后重试");
                    Thread.sleep(Math.max(delay, 0) * 1000L);
                } else {
                    Toast(handError, TAG, "开始请求接口...");
                }

                String response = httpGet(requestUrl);
                Toast(handError, TAG, "发送状态：" + response);
                if (response.contains("\"message\":\"success\"") || response.contains("success")) {
                    LogUtil.updateLog(logId, 1, response);
                } else {
                    LogUtil.updateLog(logId, 0, response);
                }
                return;
            } catch (Exception e) {
                lastError = e;
                Log.e(TAG, "send failed", e);
            }
        }
        String msg = lastError == null ? "unknown" : lastError.getMessage();
        LogUtil.updateLog(logId, 0, msg);
        Toast(handError, TAG, "发送失败：" + msg);
    }

    private static String httpGet(String requestUrl) throws Exception {
        HttpURLConnection connection = null;
        InputStream inputStream = null;
        try {
            connection = (HttpURLConnection) new URL(requestUrl).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.setUseCaches(false);
            int code = connection.getResponseCode();
            inputStream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
            String body = inputStream == null ? "" : readAll(inputStream);
            return code + " " + body;
        } finally {
            if (inputStream != null) inputStream.close();
            if (connection != null) connection.disconnect();
        }
    }

    private static String readAll(InputStream inputStream) throws Exception {
        byte[] buffer = new byte[4096];
        StringBuilder sb = new StringBuilder();
        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            sb.append(new String(buffer, 0, len, StandardCharsets.UTF_8));
        }
        return sb.toString();
    }
}
