package com.idormy.sms.forwarder;

import static com.idormy.sms.forwarder.model.SenderModel.STATUS_ON;
import static com.idormy.sms.forwarder.model.SenderModel.TYPE_BARK;
import static com.idormy.sms.forwarder.model.SenderModel.TYPE_WEB_NOTIFY;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSON;
import com.idormy.sms.forwarder.adapter.SenderAdapter;
import com.idormy.sms.forwarder.model.SenderModel;
import com.idormy.sms.forwarder.model.vo.BarkSettingVo;
import com.idormy.sms.forwarder.model.vo.WebNotifySettingVo;
import com.idormy.sms.forwarder.sender.SenderBarkMsg;
import com.idormy.sms.forwarder.sender.SenderUtil;
import com.idormy.sms.forwarder.sender.SenderWebNotifyMsg;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SuppressWarnings("deprecation")
public class SenderActivity extends AppCompatActivity {
    public static final int NOTIFY = 0x9731993;
    private final String TAG = "SenderActivity";
    private List<SenderModel> senderModels = new ArrayList<>();
    private SenderAdapter adapter;

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == NOTIFY) {
                Toast.makeText(SenderActivity.this, msg.getData().getString("DATA"), Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sender);
        SenderUtil.init(SenderActivity.this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        TextView helpTip = findViewById(R.id.help_tip);
        helpTip.setVisibility(MyApplication.showHelpTip ? View.VISIBLE : View.GONE);

        initSenders();
        adapter = new SenderAdapter(SenderActivity.this, R.layout.item_sender, senderModels);
        ListView listView = findViewById(R.id.list_view_sender);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            SenderModel senderModel = senderModels.get(position);
            if (senderModel.getType() == TYPE_BARK) {
                setBark(senderModel);
            } else if (senderModel.getType() == TYPE_WEB_NOTIFY) {
                setWebNotify(senderModel);
            } else {
                Toast.makeText(SenderActivity.this, R.string.not_supported, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initSenders() {
        List<SenderModel> all = SenderUtil.getSender(null, null);
        senderModels = new ArrayList<>();
        if (all != null) {
            for (SenderModel item : all) {
                if (item.getType() == TYPE_BARK || item.getType() == TYPE_WEB_NOTIFY) {
                    senderModels.add(item);
                }
            }
        }
    }

    public void addSender(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(SenderActivity.this);
        builder.setTitle(R.string.add_sender_title);
        final String[] names = new String[]{"Bark", "Webhook"};
        final int[] types = new int[]{TYPE_BARK, TYPE_WEB_NOTIFY};
        builder.setItems(names, (dialogInterface, which) -> {
            int type = types[which];
            if (type == TYPE_BARK) {
                setBark(null);
            } else {
                setWebNotify(null);
            }
        });
        builder.show();
    }

    private void setBark(final SenderModel senderModel) {
        BarkSettingVo old = null;
        if (senderModel != null && senderModel.getJsonSetting() != null) {
            old = JSON.parseObject(senderModel.getJsonSetting(), BarkSettingVo.class);
        }

        View view1 = View.inflate(SenderActivity.this, R.layout.alert_dialog_setview_bark, null);
        final EditText editTextBarkName = view1.findViewById(R.id.editTextBarkName);
        if (senderModel != null) editTextBarkName.setText(senderModel.getName());
        final EditText editTextBarkServer = view1.findViewById(R.id.editTextBarkServer);
        if (old != null) editTextBarkServer.setText(old.getServer());
        final EditText editTextBarkIcon = view1.findViewById(R.id.editTextBarkIcon);
        if (old != null) editTextBarkIcon.setText(old.getIcon());

        Button buttonBarkOk = view1.findViewById(R.id.buttonBarkOk);
        Button buttonBarkDel = view1.findViewById(R.id.buttonBarkDel);
        Button buttonBarkTest = view1.findViewById(R.id.buttonBarkTest);
        AlertDialog show = new AlertDialog.Builder(SenderActivity.this)
                .setTitle(R.string.setbarktitle)
                .setIcon(R.mipmap.bark)
                .setView(view1)
                .show();

        buttonBarkOk.setOnClickListener(view -> {
            BarkSettingVo value = new BarkSettingVo(editTextBarkServer.getText().toString(), editTextBarkIcon.getText().toString());
            if (senderModel == null) {
                SenderModel model = new SenderModel();
                model.setName(editTextBarkName.getText().toString());
                model.setType(TYPE_BARK);
                model.setStatus(STATUS_ON);
                model.setJsonSetting(JSON.toJSONString(value));
                SenderUtil.addSender(model);
            } else {
                senderModel.setName(editTextBarkName.getText().toString());
                senderModel.setType(TYPE_BARK);
                senderModel.setStatus(STATUS_ON);
                senderModel.setJsonSetting(JSON.toJSONString(value));
                SenderUtil.updateSender(senderModel);
            }
            initSenders();
            if (adapter != null) adapter.update(senderModels);
            show.dismiss();
        });

        buttonBarkDel.setOnClickListener(view -> {
            if (senderModel != null) {
                SenderUtil.delSender(senderModel.getId());
                initSenders();
                if (adapter != null) adapter.del(senderModels);
            }
            show.dismiss();
        });

        buttonBarkTest.setOnClickListener(view -> {
            String barkServer = editTextBarkServer.getText().toString();
            if (!barkServer.isEmpty()) {
                try {
                    SenderBarkMsg.sendMsg(0, handler, barkServer, editTextBarkIcon.getText().toString(), getString(R.string.test_phone_num), getString(R.string.test_sms), getString(R.string.test_group_name));
                } catch (Exception e) {
                    Toast.makeText(SenderActivity.this, getString(R.string.failed_to_fwd) + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(SenderActivity.this, R.string.invalid_bark_server, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setWebNotify(final SenderModel senderModel) {
        WebNotifySettingVo old = null;
        if (senderModel != null && senderModel.getJsonSetting() != null) {
            old = JSON.parseObject(senderModel.getJsonSetting(), WebNotifySettingVo.class);
        }

        View view1 = View.inflate(SenderActivity.this, R.layout.alert_dialog_setview_webnotify, null);
        final EditText editTextName = view1.findViewById(R.id.editTextWebNotifyName);
        if (senderModel != null) editTextName.setText(senderModel.getName());
        final EditText editTextServer = view1.findViewById(R.id.editTextWebNotifyWebServer);
        if (old != null) editTextServer.setText(old.getWebServer());
        final EditText editTextParams = view1.findViewById(R.id.editTextWebNotifyWebParams);
        if (old != null) editTextParams.setText(old.getWebParams());
        final EditText editTextSecret = view1.findViewById(R.id.editTextWebNotifySecret);
        if (old != null) editTextSecret.setText(old.getSecret());
        final RadioGroup radioMethod = view1.findViewById(R.id.radioGroupWebNotifyMethod);
        if (old != null) radioMethod.check(old.getWebNotifyMethodCheckId());

        Button buttonOk = view1.findViewById(R.id.buttonWebNotifyOk);
        Button buttonDel = view1.findViewById(R.id.buttonWebNotifyDel);
        Button buttonTest = view1.findViewById(R.id.buttonWebNotifyTest);
        AlertDialog show = new AlertDialog.Builder(SenderActivity.this)
                .setTitle(R.string.setwebnotifytitle)
                .setIcon(R.mipmap.webhook)
                .setView(view1)
                .show();

        buttonOk.setOnClickListener(view -> {
            WebNotifySettingVo value = new WebNotifySettingVo(
                    editTextServer.getText().toString(),
                    editTextSecret.getText().toString(),
                    radioMethod.getCheckedRadioButtonId() == R.id.radioWebNotifyMethodGet ? "GET" : "POST",
                    editTextParams.getText().toString()
            );
            if (senderModel == null) {
                SenderModel model = new SenderModel();
                model.setName(editTextName.getText().toString());
                model.setType(TYPE_WEB_NOTIFY);
                model.setStatus(STATUS_ON);
                model.setJsonSetting(JSON.toJSONString(value));
                SenderUtil.addSender(model);
            } else {
                senderModel.setName(editTextName.getText().toString());
                senderModel.setType(TYPE_WEB_NOTIFY);
                senderModel.setStatus(STATUS_ON);
                senderModel.setJsonSetting(JSON.toJSONString(value));
                SenderUtil.updateSender(senderModel);
            }
            initSenders();
            if (adapter != null) adapter.update(senderModels);
            show.dismiss();
        });

        buttonDel.setOnClickListener(view -> {
            if (senderModel != null) {
                SenderUtil.delSender(senderModel.getId());
                initSenders();
                if (adapter != null) adapter.del(senderModels);
            }
            show.dismiss();
        });

        buttonTest.setOnClickListener(view -> {
            String webServer = editTextServer.getText().toString();
            if (!webServer.isEmpty()) {
                try {
                    String method = radioMethod.getCheckedRadioButtonId() == R.id.radioWebNotifyMethodGet ? "GET" : "POST";
                    SenderWebNotifyMsg.sendMsg(0, handler, webServer, editTextParams.getText().toString(), editTextSecret.getText().toString(), method, "SmsForwarder Title", R.string.test_content + (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())));
                } catch (Exception e) {
                    Toast.makeText(SenderActivity.this, getString(R.string.failed_to_fwd) + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(SenderActivity.this, R.string.invalid_webserver, Toast.LENGTH_LONG).show();
            }
        });
    }
}
