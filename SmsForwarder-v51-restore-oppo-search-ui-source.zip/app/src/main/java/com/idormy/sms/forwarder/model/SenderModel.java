package com.idormy.sms.forwarder.model;

import androidx.annotation.NonNull;

import com.idormy.sms.forwarder.R;

import lombok.Data;

@SuppressWarnings("unused")
@Data
public class SenderModel {
    public static final int STATUS_ON = 1;
    public static final int STATUS_OFF = 0;
    public static final int TYPE_DINGDING = 0;
    public static final int TYPE_EMAIL = 1;
    public static final int TYPE_BARK = 2;
    public static final int TYPE_WEB_NOTIFY = 3;
    public static final int TYPE_QYWX_GROUP_ROBOT = 4;
    public static final int TYPE_QYWX_APP = 5;
    public static final int TYPE_SERVER_CHAN = 6;
    public static final int TYPE_TELEGRAM = 7;
    public static final int TYPE_SMS = 8;
    public static final int TYPE_FEISHU = 9;
    public static final int TYPE_PUSHPLUS = 10;
    private Long id;
    private String name;
    private int status;
    private int type;
    private String jsonSetting;
    private long time;

    public SenderModel() {
    }

    public SenderModel(String name, int status, int type, String jsonSetting) {
        this.name = name;
        this.status = status == STATUS_ON ? STATUS_ON : STATUS_OFF;
        this.type = type;
        this.jsonSetting = jsonSetting;
    }

    public static int getImageId(int type) {
        switch (type) {
            case (TYPE_BARK):
                return R.mipmap.bark;
            case (TYPE_WEB_NOTIFY):
            default:
                return R.mipmap.webhook;
        }
    }

    public int getImageId() {
        return getImageId(type);
    }

    public int getSmsSimSlotId(int id) {
        // SMS发送通道已精简移除；这里保留兼容方法，避免旧代码引用导致编译失败。
        return 0;
    }

    @NonNull
    @Override
    public String toString() {
        return "SenderModel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", status=" + status +
                ", type=" + type +
                ", jsonSetting='" + jsonSetting + '\'' +
                ", time=" + time +
                '}';
    }
}
