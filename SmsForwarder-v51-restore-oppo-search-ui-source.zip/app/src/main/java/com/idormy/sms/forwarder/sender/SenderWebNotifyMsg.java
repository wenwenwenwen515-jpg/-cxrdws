package com.idormy.sms.forwarder.sender;

import android.os.Handler;
import android.util.Base64;
import android.util.Log;

import com.idormy.sms.forwarder.utils.LogUtil;
import com.idormy.sms.forwarder.utils.SettingUtil;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class SenderWebNotifyMsg extends SenderBaseMsg {
    static final String TAG = "SenderWebNotifyMsg";

    public static void sendMsg(final long logId, final Handler handError, String webServer, String webParams, String secret, String method, String from, String content) throws Exception {
        if (webServer == null || webServer.trim().isEmpty()) {
            return;
        }
        final RequestData data = buildRequest(webServer.trim(), webParams, secret, method, from, content);
        new Thread(() -> requestWithRetry(logId, handError, data), "sender-webhook").start();
    }

    private static RequestData buildRequest(String webServer, String webParams, String secret, String method, String from, String content) throws Exception {
        String safeFrom = from == null ? "" : from;
        String safeContent = content == null ? "" : content;
        String safeMethod = method == null ? "POST" : method.toUpperCase();
        long timestamp = System.currentTimeMillis();
        String sign = "";
        if (secret != null && !secret.isEmpty()) {
            String stringToSign = timestamp + "\n" + secret;
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            sign = URLEncoder.encode(new String(Base64.encode(mac.doFinal(stringToSign.getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP)), "UTF-8");
        }

        RequestData data = new RequestData();
        if ("GET".equals(safeMethod)) {
            StringBuilder url = new StringBuilder(webServer);
            url.append(webServer.contains("?") ? "&" : "?")
                    .append("from=").append(encode(safeFrom))
                    .append("&content=").append(encode(safeContent));
            if (secret != null && !secret.isEmpty()) {
                url.append("&timestamp=").append(timestamp).append("&sign=").append(sign);
            }
            data.url = url.toString();
            data.method = "GET";
            data.contentType = "";
            data.body = "";
            return data;
        }

        data.url = webServer;
        data.method = "POST";
        if (webParams != null && webParams.contains("[msg]")) {
            String bodyMsg;
            if (webParams.startsWith("{")) {
                bodyMsg = webParams.replace("[msg]", safeContent.replace("\n", "\\n"));
                data.contentType = "application/json;charset=utf-8";
            } else {
                bodyMsg = webParams.replace("[msg]", encode(safeContent));
                data.contentType = "application/x-www-form-urlencoded";
            }
            data.body = bodyMsg;
        } else {
            StringBuilder body = new StringBuilder();
            body.append("from=").append(encode(safeFrom)).append("&content=").append(encode(safeContent));
            if (secret != null && !secret.isEmpty()) {
                body.append("&timestamp=").append(timestamp).append("&sign=").append(sign);
            }
            data.body = body.toString();
            data.contentType = "application/x-www-form-urlencoded";
        }
        return data;
    }

    private static String encode(String value) throws Exception {
        return URLEncoder.encode(value == null ? "" : value, "UTF-8");
    }

    private static void requestWithRetry(long logId, Handler handError, RequestData data) {
        int[] delays = new int[]{0,
                SettingUtil.getRetryDelayTime(1),
                SettingUtil.getRetryDelayTime(2),
                SettingUtil.getRetryDelayTime(3),
                SettingUtil.getRetryDelayTime(4),
                SettingUtil.getRetryDelayTime(5)};
        Exception lastError = null;
        for (int attempt = 0; attempt < delays.length; attempt++) {
            try {
                if (attempt > 0) {
                    int delay = delays[attempt];
                    Toast(handError, TAG, "请求接口异常，" + delay + "秒后重试");
                    Thread.sleep(Math.max(delay, 0) * 1000L);
                } else {
                    Toast(handError, TAG, "开始请求接口...");
                }
                ResponseData response = execute(data);
                Toast(handError, TAG, "发送状态：" + response.body);
                LogUtil.updateLog(logId, response.code == 200 ? 1 : 0, response.code + " " + response.body);
                return;
            } catch (Exception e) {
                lastError = e;
                Log.e(TAG, "send failed", e);
            }
        }
        String msg = lastError == null ? "unknown" : lastError.getMessage();
        LogUtil.updateLog(logId, 0, msg);
        Toast(handError, TAG, "发送失败：" + msg);
    }

    private static ResponseData execute(RequestData data) throws Exception {
        HttpURLConnection connection = null;
        InputStream inputStream = null;
        try {
            connection = (HttpURLConnection) new URL(data.url).openConnection();
            connection.setRequestMethod(data.method);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.setUseCaches(false);
            if ("POST".equals(data.method)) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", data.contentType);
                byte[] bytes = data.body == null ? new byte[0] : data.body.getBytes(StandardCharsets.UTF_8);
                connection.setRequestProperty("Content-Length", String.valueOf(bytes.length));
                OutputStream outputStream = connection.getOutputStream();
                outputStream.write(bytes);
                outputStream.flush();
                outputStream.close();
            }
            int code = connection.getResponseCode();
            inputStream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
            ResponseData responseData = new ResponseData();
            responseData.code = code;
            responseData.body = inputStream == null ? "" : readAll(inputStream);
            return responseData;
        } finally {
            if (inputStream != null) inputStream.close();
            if (connection != null) connection.disconnect();
        }
    }

    private static String readAll(InputStream inputStream) throws Exception {
        byte[] buffer = new byte[4096];
        StringBuilder sb = new StringBuilder();
        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            sb.append(new String(buffer, 0, len, StandardCharsets.UTF_8));
        }
        return sb.toString();
    }

    private static class RequestData {
        String url;
        String method;
        String contentType;
        String body;
    }

    private static class ResponseData {
        int code;
        String body;
    }
}
