package com.idormy.sms.forwarder;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.idormy.sms.forwarder.sender.SendHistory;
import com.idormy.sms.forwarder.service.FrontService;
import com.idormy.sms.forwarder.utils.CommonUtil;
import com.idormy.sms.forwarder.utils.Define;
import com.idormy.sms.forwarder.utils.DefaultPushConfigUtil;
import com.idormy.sms.forwarder.utils.PhoneUtils;
import com.idormy.sms.forwarder.utils.RecentsHideUtil;
import com.idormy.sms.forwarder.utils.SettingUtil;

import java.util.ArrayList;
import java.util.List;

public class MyApplication extends Application {
    private static final String TAG = "MyApplication";
    //SIM卡信息
    public static List<PhoneUtils.SimInfo> SimInfoList = new ArrayList<>();
    //是否关闭页面提示
    public static boolean showHelpTip = true;
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
    }

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate");
        super.onCreate();

        try {
            Intent intent = new Intent(this, FrontService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            SendHistory.init(this);
            SettingUtil.init(this);
            registerRecentsHideLifecycle();
            DefaultPushConfigUtil.applyDefaultPushConfig(this);


            SharedPreferences sp = MyApplication.this.getSharedPreferences(Define.SP_CONFIG, Context.MODE_PRIVATE);
            showHelpTip = sp.getBoolean(Define.SP_CONFIG_SWITCH_HELP_TIP, true);

            RecentsHideUtil.applyIfEnabled(this);
        } catch (Exception e) {
            Log.e(TAG, "onCreate:", e);
        }
    }

    /**
     * v42 固定隐藏：开启“隐藏列表”后，每个页面创建/恢复/停止时都重新设置最近任务隐藏。
     * 这里只隐藏任务卡片，不清后台，不杀进程，不停止前台服务。
     */
    private void registerRecentsHideLifecycle() {
        try {
            registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
                @Override
                public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                    RecentsHideUtil.applyIfEnabled(activity);
                }

                @Override
                public void onActivityStarted(Activity activity) {
                    RecentsHideUtil.applyIfEnabled(activity);
                }

                @Override
                public void onActivityResumed(Activity activity) {
                    RecentsHideUtil.applyIfEnabled(activity);
                }

                @Override
                public void onActivityPaused(Activity activity) {
                    RecentsHideUtil.applyIfEnabled(activity);
                }

                @Override
                public void onActivityStopped(Activity activity) {
                    RecentsHideUtil.applyIfEnabled(activity);
                }

                @Override
                public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
                }

                @Override
                public void onActivityDestroyed(Activity activity) {
                    RecentsHideUtil.applyIfEnabled(activity);
                }
            });
        } catch (Throwable t) {
            Log.e(TAG, "registerRecentsHideLifecycle:", t);
        }
    }

}
