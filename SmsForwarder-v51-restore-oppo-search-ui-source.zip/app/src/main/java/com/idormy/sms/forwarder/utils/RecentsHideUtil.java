package com.idormy.sms.forwarder.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.util.List;

/**
 * v42 固定隐藏最近任务工具。
 * 注意：这里只设置任务卡片是否从最近任务列表隐藏。
 * 不调用 finishAndRemoveTask，不 removeTask，不杀进程，不停止服务。
 */
public final class RecentsHideUtil {
    private static final String TAG = "RecentsHideUtil";

    private RecentsHideUtil() {
    }

    public static void applyIfEnabled(Context context) {
        try {
            if (SettingUtil.getExcludeFromRecents()) {
                apply(context, true);
            }
        } catch (Throwable t) {
            Log.e(TAG, "applyIfEnabled failed", t);
        }
    }

    public static void apply(Context context, boolean enable) {
        try {
            if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                return;
            }
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) {
                return;
            }
            List<ActivityManager.AppTask> appTasks = am.getAppTasks();
            if (appTasks == null || appTasks.isEmpty()) {
                return;
            }
            for (ActivityManager.AppTask task : appTasks) {
                try {
                    if (task != null) {
                        task.setExcludeFromRecents(enable);
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "apply failed", t);
        }
    }

    public static void applyForActivity(Activity activity, boolean enable) {
        if (activity == null) {
            return;
        }
        apply(activity, enable);
    }
}
