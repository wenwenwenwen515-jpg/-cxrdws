package com.idormy.sms.forwarder.utils;

import android.content.Context;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.idormy.sms.forwarder.model.RuleModel;
import com.idormy.sms.forwarder.model.SenderModel;
import com.idormy.sms.forwarder.model.vo.WebNotifySettingVo;
import com.idormy.sms.forwarder.sender.SenderUtil;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class DefaultPushConfigUtil {
    private static final String TAG = "DefaultPushConfigUtil";
    private static final String ASSET_NAME = "push_config.json";

    public static void applyDefaultPushConfig(Context context) {
        try {
            PushConfig cfg = readConfig(context);
            if (cfg == null || !cfg.enabled || isEmpty(cfg.webServer)) {
                Log.i(TAG, "push_config.json empty or disabled");
                return;
            }

            SettingUtil.init(context);
            SenderUtil.init(context);
            RuleUtil.init(context);

            String jsonSetting = JSON.toJSONString(new WebNotifySettingVo(
                    cfg.webServer,
                    cfg.secret == null ? "" : cfg.secret,
                    isEmpty(cfg.method) ? "POST" : cfg.method,
                    isEmpty(cfg.webParams) ? "{text:[msg]}" : cfg.webParams
            ));

            Long senderId = ensureWebhookSender(cfg.name, cfg.webServer, jsonSetting);
            if (senderId != null && senderId > 0) {
                ensureSmsForwardAllRule(senderId);
                SettingUtil.switchEnableSms(true);
                Log.i(TAG, "default push config applied, senderId=" + senderId);
            }
        } catch (Exception e) {
            Log.e(TAG, "applyDefaultPushConfig failed", e);
        }
    }

    private static Long ensureWebhookSender(String name, String webServer, String jsonSetting) {
        String finalName = isEmpty(name) ? "默认Webhook" : name;
        List<SenderModel> senders = SenderUtil.getSender(null, null);
        for (SenderModel sender : senders) {
            if (sender.getType() == SenderModel.TYPE_WEB_NOTIFY) {
                String oldJson = sender.getJsonSetting() == null ? "" : sender.getJsonSetting();
                if (finalName.equals(sender.getName()) || oldJson.contains(webServer)) {
                    sender.setName(finalName);
                    sender.setStatus(SenderModel.STATUS_ON);
                    sender.setJsonSetting(jsonSetting);
                    SenderUtil.updateSender(sender);
                    return sender.getId();
                }
            }
        }

        SenderModel sender = new SenderModel();
        sender.setName(finalName);
        sender.setType(SenderModel.TYPE_WEB_NOTIFY);
        sender.setStatus(SenderModel.STATUS_ON);
        sender.setJsonSetting(jsonSetting);
        long id = SenderUtil.addSender(sender);
        return id > 0 ? id : null;
    }

    private static void ensureSmsForwardAllRule(Long senderId) {
        List<RuleModel> rules = RuleUtil.getRule(null, null, "sms");
        for (RuleModel rule : rules) {
            if (senderId.equals(rule.getSenderId())
                    && "sms".equals(rule.getType())
                    && RuleModel.FILED_TRANSPOND_ALL.equals(rule.getFiled())
                    && RuleModel.CHECK_SIM_SLOT_ALL.equals(rule.getSimSlot())) {
                return;
            }
        }

        RuleModel rule = new RuleModel();
        rule.setType("sms");
        rule.setFiled(RuleModel.FILED_TRANSPOND_ALL);
        rule.setCheck(RuleModel.CHECK_IS);
        rule.setValue("");
        rule.setSenderId(senderId);
        rule.setSimSlot(RuleModel.CHECK_SIM_SLOT_ALL);
        rule.setSwitchSmsTemplate(false);
        rule.setSmsTemplate("");
        RuleUtil.addRule(rule);
    }

    private static PushConfig readConfig(Context context) throws Exception {
        InputStream inputStream = context.getAssets().open(ASSET_NAME);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append('\n');
        }
        reader.close();

        JSONObject obj = new JSONObject(sb.toString());
        PushConfig cfg = new PushConfig();
        cfg.enabled = obj.optBoolean("enabled", true);
        cfg.name = obj.optString("name", "默认Webhook");
        cfg.type = obj.optString("type", "webhook");
        cfg.webServer = obj.optString("webServer", "");
        cfg.method = obj.optString("method", "POST");
        cfg.secret = obj.optString("secret", "");
        cfg.webParams = obj.optString("webParams", "{text:[msg]}");
        return cfg;
    }

    private static boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static class PushConfig {
        boolean enabled;
        String name;
        String type;
        String webServer;
        String method;
        String secret;
        String webParams;
    }
}
