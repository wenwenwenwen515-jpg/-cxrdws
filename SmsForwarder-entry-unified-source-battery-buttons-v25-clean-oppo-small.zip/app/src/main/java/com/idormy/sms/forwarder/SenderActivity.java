package com.idormy.sms.forwarder;

import static com.idormy.sms.forwarder.model.SenderModel.STATUS_ON;
import static com.idormy.sms.forwarder.model.SenderModel.TYPE_WEB_NOTIFY;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSON;
import com.idormy.sms.forwarder.adapter.SenderAdapter;
import com.idormy.sms.forwarder.model.SenderModel;
import com.idormy.sms.forwarder.model.vo.WebNotifySettingVo;
import com.idormy.sms.forwarder.sender.SenderUtil;
import com.idormy.sms.forwarder.sender.SenderWebNotifyMsg;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SuppressWarnings("deprecation")
public class SenderActivity extends AppCompatActivity {

    public static final int NOTIFY = 0x9731993;
    private final String TAG = "SenderActivity";
    private List<SenderModel> senderModels = new ArrayList<>();
    private SenderAdapter adapter;

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == NOTIFY) {
                Toast.makeText(SenderActivity.this, msg.getData().getString("DATA"), Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sender);
        SenderUtil.init(SenderActivity.this);
    }

    @Override
    protected void onStart() {
        super.onStart();

        TextView helpTip = findViewById(R.id.help_tip);
        helpTip.setVisibility(MyApplication.showHelpTip ? View.VISIBLE : View.GONE);

        initSenders();
        adapter = new SenderAdapter(SenderActivity.this, R.layout.item_sender, senderModels);
        ListView listView = findViewById(R.id.list_view_sender);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> setWebNotify(senderModels.get(position)));

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(SenderActivity.this);
            builder.setTitle(R.string.delete_sender_title);
            builder.setMessage(R.string.delete_sender_tips);
            builder.setPositiveButton(R.string.confirm, (dialog, which) -> {
                SenderUtil.delSender(senderModels.get(position).getId());
                initSenders();
                adapter.del(senderModels);
                Toast.makeText(getBaseContext(), R.string.delete_sender_toast, Toast.LENGTH_SHORT).show();
            });
            builder.setNegativeButton(R.string.cancel, (dialog, which) -> { });
            builder.create().show();
            return true;
        });
    }

    private void initSenders() {
        List<SenderModel> all = SenderUtil.getSender(null, null);
        senderModels = new ArrayList<>();
        for (SenderModel sender : all) {
            if (sender != null && sender.getType() == TYPE_WEB_NOTIFY) {
                senderModels.add(sender);
            }
        }
    }

    public void addSender(View view) {
        setWebNotify(null);
    }

    private void setWebNotify(final SenderModel senderModel) {
        WebNotifySettingVo webNotifySettingVo = null;
        if (senderModel != null && senderModel.getJsonSetting() != null) {
            webNotifySettingVo = JSON.parseObject(senderModel.getJsonSetting(), WebNotifySettingVo.class);
        }

        final AlertDialog dialog = new AlertDialog.Builder(SenderActivity.this).create();
        View view = View.inflate(SenderActivity.this, R.layout.alert_dialog_setview_webnotify, null);

        final EditText editTextName = view.findViewById(R.id.editTextWebNotifyName);
        final RadioGroup radioGroupMethod = view.findViewById(R.id.radioGroupWebNotifyMethod);
        final EditText editTextWebServer = view.findViewById(R.id.editTextWebNotifyWebServer);
        final EditText editTextWebParams = view.findViewById(R.id.editTextWebNotifyWebParams);
        final EditText editTextSecret = view.findViewById(R.id.editTextWebNotifySecret);

        if (senderModel != null) {
            editTextName.setText(senderModel.getName());
        }
        if (webNotifySettingVo != null) {
            editTextWebServer.setText(webNotifySettingVo.getWebServer());
            editTextWebParams.setText(webNotifySettingVo.getWebParams());
            editTextSecret.setText(webNotifySettingVo.getSecret());
            radioGroupMethod.check(webNotifySettingVo.getWebNotifyMethodCheckId());
        }

        Button buttonTest = view.findViewById(R.id.buttonWebNotifyTest);
        Button buttonDel = view.findViewById(R.id.buttonWebNotifyDel);
        Button buttonOk = view.findViewById(R.id.buttonWebNotifyOk);

        buttonTest.setOnClickListener(v -> {
            try {
                String method = radioGroupMethod.getCheckedRadioButtonId() == R.id.radioWebNotifyMethodGet ? "GET" : "POST";
                SenderWebNotifyMsg.sendMsg(0, handler,
                        editTextWebServer.getText().toString(),
                        editTextWebParams.getText().toString(),
                        editTextSecret.getText().toString(),
                        method,
                        getString(R.string.test_phone_num),
                        R.string.test_content + (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())));
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        buttonDel.setOnClickListener(v -> {
            if (senderModel != null) {
                SenderUtil.delSender(senderModel.getId());
                initSenders();
                if (adapter != null) adapter.del(senderModels);
            }
            dialog.dismiss();
        });

        buttonOk.setOnClickListener(v -> {
            String name = editTextName.getText().toString().trim();
            if (name.isEmpty()) name = "Webhook";
            String method = radioGroupMethod.getCheckedRadioButtonId() == R.id.radioWebNotifyMethodGet ? "GET" : "POST";
            WebNotifySettingVo newSetting = new WebNotifySettingVo(
                    editTextWebServer.getText().toString().trim(),
                    editTextSecret.getText().toString().trim(),
                    method,
                    editTextWebParams.getText().toString().trim());

            if (senderModel == null) {
                SenderModel newSender = new SenderModel();
                newSender.setName(name);
                newSender.setType(TYPE_WEB_NOTIFY);
                newSender.setStatus(STATUS_ON);
                newSender.setJsonSetting(JSON.toJSONString(newSetting));
                SenderUtil.addSender(newSender);
            } else {
                senderModel.setName(name);
                senderModel.setType(TYPE_WEB_NOTIFY);
                senderModel.setStatus(STATUS_ON);
                senderModel.setJsonSetting(JSON.toJSONString(newSetting));
                SenderUtil.updateSender(senderModel);
            }
            initSenders();
            if (adapter != null) adapter.update(senderModels);
            dialog.dismiss();
        });

        dialog.setView(view);
        dialog.show();
    }
}
