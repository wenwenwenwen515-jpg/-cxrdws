package com.idormy.sms.forwarder.sender;

import android.content.Context;
import android.os.Handler;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.idormy.sms.forwarder.model.LogModel;
import com.idormy.sms.forwarder.model.RuleModel;
import com.idormy.sms.forwarder.model.SenderModel;
import com.idormy.sms.forwarder.model.vo.SmsVo;
import com.idormy.sms.forwarder.model.vo.WebNotifySettingVo;
import com.idormy.sms.forwarder.utils.LogUtil;
import com.idormy.sms.forwarder.utils.RuleUtil;

import java.util.List;

public class SendUtil {
    private static final String TAG = "SendUtil";

    public static void send_msg_list(Context context, List<SmsVo> smsVoList, int simId, String type) {
        Log.i(TAG, "send_msg_list size: " + smsVoList.size());
        for (SmsVo smsVo : smsVoList) {
            SendUtil.send_msg(context, smsVo, simId, type);
        }
    }

    public static void send_msg(Context context, SmsVo smsVo, int simId, String type) {
        Log.i(TAG, "send_msg smsVo:" + smsVo);
        RuleUtil.init(context);
        LogUtil.init(context);

        String key = "SIM" + simId;
        List<RuleModel> ruleList = RuleUtil.getRule(null, key, type);
        if (!ruleList.isEmpty()) {
            SenderUtil.init(context);
            for (RuleModel ruleModel : ruleList) {
                try {
                    if (ruleModel.checkMsg(smsVo)) {
                        List<SenderModel> senderModels = SenderUtil.getSender(ruleModel.getSenderId(), null);
                        for (SenderModel senderModel : senderModels) {
                            if (senderModel.getType() != SenderModel.TYPE_WEB_NOTIFY) continue;
                            long logId = LogUtil.addLog(new LogModel(type, smsVo.getMobile(), smsVo.getContent(), smsVo.getSimInfo(), ruleModel.getId()));
                            String smsTemplate = ruleModel.getSwitchSmsTemplate() ? ruleModel.getSmsTemplate() : "";
                            SendUtil.senderSendMsgNoHandError(smsVo, senderModel, logId, smsTemplate);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "send_msg: fail checkMsg:", e);
                }
            }
        }
    }

    public static void sendMsgByRuleModelSenderId(final Handler handError, RuleModel ruleModel, SmsVo smsVo, Long senderId) throws Exception {
        if (senderId == null) {
            throw new Exception("先新建并选择发送通道");
        }

        String testSim = smsVo.getSimInfo().substring(0, 4);
        String ruleSim = ruleModel.getSimSlot();

        if (!ruleSim.equals("ALL") && !ruleSim.equals(testSim)) {
            throw new Exception("接收卡槽未匹配中规则");
        }

        if (!ruleModel.checkMsg(smsVo)) {
            throw new Exception("短信未匹配中规则");
        }

        List<SenderModel> senderModels = SenderUtil.getSender(senderId, null);
        if (senderModels.isEmpty()) {
            throw new Exception("未找到发送通道");
        }

        for (SenderModel senderModel : senderModels) {
            if (senderModel.getType() != SenderModel.TYPE_WEB_NOTIFY) {
                throw new Exception("当前版本仅支持 Webhook 通道");
            }
            SendUtil.senderSendMsg(handError, smsVo, senderModel, 0, "");
        }
    }

    public static void senderSendMsgNoHandError(SmsVo smsVo, SenderModel senderModel, long logId, String smsTemplate) {
        SendUtil.senderSendMsg(null, smsVo, senderModel, logId, smsTemplate);
    }

    public static void senderSendMsg(Handler handError, SmsVo smsVo, SenderModel senderModel, long logId, String smsTemplate) {
        if (senderModel == null || senderModel.getType() != SenderModel.TYPE_WEB_NOTIFY) return;
        try {
            WebNotifySettingVo webNotifySettingVo = JSON.parseObject(senderModel.getJsonSetting(), WebNotifySettingVo.class);
            if (webNotifySettingVo != null) {
                SenderWebNotifyMsg.sendMsg(
                        logId,
                        handError,
                        webNotifySettingVo.getWebServer(),
                        webNotifySettingVo.getWebParams(),
                        webNotifySettingVo.getSecret(),
                        webNotifySettingVo.getMethod(),
                        smsVo.getMobile(),
                        smsVo.getSmsVoForSend(smsTemplate)
                );
            }
        } catch (Exception e) {
            LogUtil.updateLog(logId, 0, e.getMessage());
            Log.e(TAG, "senderSendMsg: Webhook error " + e.getMessage());
        }
    }
}
