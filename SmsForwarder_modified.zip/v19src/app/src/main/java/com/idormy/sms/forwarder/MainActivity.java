package com.idormy.sms.forwarder;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.graphics.Color;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.idormy.sms.forwarder.adapter.LogAdapter;
import com.idormy.sms.forwarder.model.vo.LogVo;
import com.idormy.sms.forwarder.service.FrontService;
import com.idormy.sms.forwarder.utils.CommonUtil;
import com.idormy.sms.forwarder.utils.KeepAliveUtils;
import com.idormy.sms.forwarder.utils.LogUtil;
import com.idormy.sms.forwarder.utils.NetUtil;
import com.idormy.sms.forwarder.utils.PhoneUtils;
import com.idormy.sms.forwarder.utils.SettingUtil;
import com.idormy.sms.forwarder.utils.SmsUtil;
import com.idormy.sms.forwarder.utils.TimeUtil;
import com.umeng.analytics.MobclickAgent;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RefreshListView.IRefreshListener {

    private final String TAG = "MainActivity";
    // logVoList用于存储数据
    private List<LogVo> logVos = new ArrayList<>();
    private LogAdapter adapter;
    private RefreshListView listView;
    private Intent serviceIntent;
    private String currentType = "sms";
    private TextView deviceInfoLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        LogUtil.init(this);
        Log.d(TAG, "onCreate");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addCalculatorReturnButton();
        addDeviceModelLabel();

        //检查权限是否获取
        PackageManager pm = getPackageManager();
        CommonUtil.CheckPermission(pm, this);
        SettingUtil.switchEnablePhone(false);
        SettingUtil.switchEnableAppNotify(false);

        //获取SIM信息
        PhoneUtils.init(this);

        //短信&网络组件初始化
        SmsUtil.init(this);
        NetUtil.init(this);

        //前台服务
        try {
            serviceIntent = new Intent(MainActivity.this, FrontService.class);
            serviceIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onCreate:", e);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    private void addCalculatorReturnButton() {
        try {
            FrameLayout content = findViewById(android.R.id.content);

            LinearLayout quickPanel = new LinearLayout(this);
            quickPanel.setOrientation(LinearLayout.VERTICAL);
            quickPanel.setGravity(Gravity.CENTER);

            Button batteryButton = buildFloatingButton("电池", "#2E7D32");
            Button permissionButton = buildFloatingButton("权限", "#1565C0");
            Button autoStartButton = buildFloatingButton("自启动", "#EF6C00");
            Button smsButton = buildFloatingButton("短信", "#6A1B9A");
            Button calculatorButton = buildFloatingButton("▦", "#222222");
            Button desktopButton = buildFloatingButton("桌面", "#37474F");
            Button huaweiGuideButton = buildFloatingButton("华为", "#455A64");
            Button oppoGuideButton = buildFloatingButton("OPPO", "#455A64");
            Button vivoGuideButton = buildFloatingButton("vivo", "#455A64");
            Button xiaomiGuideButton = buildFloatingButton("小米", "#455A64");

            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(dp(62), dp(44));
            itemLp.setMargins(0, dp(4), 0, dp(4));
            quickPanel.addView(batteryButton, itemLp);
            quickPanel.addView(permissionButton, new LinearLayout.LayoutParams(dp(62), dp(44)));
            ((LinearLayout.LayoutParams) permissionButton.getLayoutParams()).setMargins(0, dp(4), 0, dp(4));
            quickPanel.addView(autoStartButton, new LinearLayout.LayoutParams(dp(62), dp(44)));
            ((LinearLayout.LayoutParams) autoStartButton.getLayoutParams()).setMargins(0, dp(4), 0, dp(4));
            quickPanel.addView(smsButton, new LinearLayout.LayoutParams(dp(62), dp(44)));
            ((LinearLayout.LayoutParams) smsButton.getLayoutParams()).setMargins(0, dp(4), 0, dp(4));
            quickPanel.addView(calculatorButton, new LinearLayout.LayoutParams(dp(62), dp(36)));
            quickPanel.addView(desktopButton, new LinearLayout.LayoutParams(dp(62), dp(36)));
            ((LinearLayout.LayoutParams) desktopButton.getLayoutParams()).setMargins(0, dp(3), 0, dp(3));
            quickPanel.addView(huaweiGuideButton, new LinearLayout.LayoutParams(dp(62), dp(38)));
            ((LinearLayout.LayoutParams) huaweiGuideButton.getLayoutParams()).setMargins(0, dp(3), 0, dp(3));
            quickPanel.addView(oppoGuideButton, new LinearLayout.LayoutParams(dp(62), dp(38)));
            ((LinearLayout.LayoutParams) oppoGuideButton.getLayoutParams()).setMargins(0, dp(3), 0, dp(3));
            quickPanel.addView(vivoGuideButton, new LinearLayout.LayoutParams(dp(62), dp(38)));
            ((LinearLayout.LayoutParams) vivoGuideButton.getLayoutParams()).setMargins(0, dp(3), 0, dp(3));
            quickPanel.addView(xiaomiGuideButton, new LinearLayout.LayoutParams(dp(62), dp(38)));
            ((LinearLayout.LayoutParams) xiaomiGuideButton.getLayoutParams()).setMargins(0, dp(3), 0, dp(3));

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(78), FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            lp.setMargins(0, 0, dp(8), 0);
            content.addView(quickPanel, lp);

            batteryButton.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                    getSharedPreferences("quick_settings", MODE_PRIVATE)
                            .edit()
                            .putBoolean("open_battery_after_optimization", true)
                            .apply();
                    KeepAliveUtils.ignoreBatteryOptimization(this);
                } else {
                    KeepAliveUtils.openAppBatterySetting(this);
                }
            });

            permissionButton.setOnClickListener(v -> {
                // 先直接向系统申请权限；如果权限都已经打开，再进入应用权限页方便检查。
                boolean requested = CommonUtil.CheckPermission(getPackageManager(), this);
                if (!requested) {
                    KeepAliveUtils.openAppPermissionSetting(this);
                }
            });
            autoStartButton.setOnClickListener(v -> KeepAliveUtils.openAutoStartSetting(this));
            smsButton.setOnClickListener(v -> KeepAliveUtils.openSmsSetting(this));
            desktopButton.setOnClickListener(v -> KeepAliveUtils.openLauncherLayoutSetting(this));
            huaweiGuideButton.setOnClickListener(v -> Toast.makeText(this, "华为教程按钮已预留", Toast.LENGTH_SHORT).show());
            oppoGuideButton.setOnClickListener(v -> Toast.makeText(this, "OPPO教程按钮已预留", Toast.LENGTH_SHORT).show());
            vivoGuideButton.setOnClickListener(v -> Toast.makeText(this, "vivo教程按钮已预留", Toast.LENGTH_SHORT).show());
            xiaomiGuideButton.setOnClickListener(v -> Toast.makeText(this, "小米教程按钮已预留", Toast.LENGTH_SHORT).show());

            calculatorButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, CalculatorActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        } catch (Exception e) {
            Log.e(TAG, "addCalculatorReturnButton:", e);
        }
    }


    private void addDeviceModelLabel() {
        try {
            FrameLayout content = findViewById(android.R.id.content);
            TextView label = new TextView(this);
            deviceInfoLabel = label;
            label.setText(getFriendlyDeviceName());
            label.setTextColor(Color.parseColor("#666666"));
            label.setTextSize(16);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            label.setGravity(Gravity.CENTER);
            label.setSingleLine(false);
            label.setMaxLines(7);
            label.setAlpha(0.86f);

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#11FFFFFF"));
            bg.setCornerRadius(dp(18));
            label.setBackground(bg);
            label.setPadding(dp(10), dp(6), dp(10), dp(6));

            // 右侧有快捷按钮，文字宽度必须留出右边空间，避免被按钮遮住。
            int width = getResources().getDisplayMetrics().widthPixels - dp(108);
            if (width < dp(180)) width = dp(180);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER_VERTICAL | Gravity.LEFT;
            lp.setMargins(dp(12), 0, dp(100), dp(90));
            content.addView(label, lp);
        } catch (Exception e) {
            Log.e(TAG, "addDeviceModelLabel:", e);
        }
    }

    private String getFriendlyDeviceName() {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String brand = Build.BRAND == null ? "" : Build.BRAND.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        String lower = (manufacturer + " " + brand).toLowerCase();
        String name;
        if (lower.contains("huawei")) {
            name = "华为";
        } else if (lower.contains("honor")) {
            name = "荣耀";
        } else if (lower.contains("xiaomi") || lower.contains("redmi") || lower.contains("poco")) {
            name = "小米";
        } else if (lower.contains("oppo") || lower.contains("oplus")) {
            name = "OPPO";
        } else if (lower.contains("oneplus")) {
            name = "一加";
        } else if (lower.contains("realme")) {
            name = "realme";
        } else if (lower.contains("vivo") || lower.contains("iqoo")) {
            name = "vivo";
        } else if (lower.contains("samsung")) {
            name = "三星";
        } else if (lower.contains("motorola") || lower.contains("moto")) {
            name = "摩托罗拉";
        } else {
            name = manufacturer.length() > 0 ? manufacturer : brand;
        }

        String modelName = getCommonModelName(model);
        String androidVersion = Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE;
        String display = Build.DISPLAY == null ? "" : Build.DISPLAY.trim();
        String systemText = "Android " + androidVersion;
        if (display.length() > 0 && !display.equalsIgnoreCase(model)) {
            systemText += " / " + display;
        }
        return "品牌：" + name + "\n"
                + "型号：" + modelName + "\n"
                + "系统：" + systemText + "\n"
                + getSimNumberDisplay();
    }

    private String getSimNumberDisplay() {
        try {
            if (MyApplication.SimInfoList == null || MyApplication.SimInfoList.isEmpty()) {
                MyApplication.SimInfoList = PhoneUtils.getSimMultiInfo();
            }
            if (MyApplication.SimInfoList == null || MyApplication.SimInfoList.isEmpty()) {
                return "手机号：未读取";
            }
            StringBuilder sb = new StringBuilder("手机号：");
            boolean hasAny = false;
            for (PhoneUtils.SimInfo simInfo : MyApplication.SimInfoList) {
                if (simInfo == null) continue;
                int slot = simInfo.mSimSlotIndex >= 0 ? simInfo.mSimSlotIndex + 1 : 1;
                String number = simInfo.mNumber == null ? "" : String.valueOf(simInfo.mNumber).trim();
                if (number.length() == 0 || "null".equalsIgnoreCase(number)) number = "未读取";
                if (hasAny) sb.append("\n　　　");
                sb.append("SIM卡").append(slot).append("：").append(number);
                hasAny = true;
            }
            if (!hasAny) return "手机号：未读取";
            return sb.toString();
        } catch (Throwable e) {
            return "手机号：未读取";
        }
    }

    private String getCommonModelName(String model) {
        if (model == null || model.trim().length() == 0) return "未知";
        String m = model.trim();
        String lower = m.toLowerCase();
        // 常见工程型号转日常名称，后续测试到更多型号可以继续追加。
        if (lower.contains("xt2201-2") || lower.contains("xt2201")) {
            return "摩托罗拉 X30（" + m + "）";
        }
        return m;
    }

    private Button buildFloatingButton(String text, String color) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(text.length() >= 3 ? 12 : 14);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(Color.WHITE);
        button.setPadding(0, 0, 0, 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(Color.parseColor(color));
        bg.setStroke(dp(1), Color.parseColor("#555555"));
        bg.setCornerRadius(dp(28));
        button.setBackground(bg);
        return button;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");

        //是否关闭页面提示
        TextView help_tip = findViewById(R.id.help_tip);
        help_tip.setVisibility(MyApplication.showHelpTip ? View.VISIBLE : View.GONE);

        // 先拿到数据并放在适配器上
        initTLogs(); //初始化数据
        showList(logVos);

        //切换日志类别
        int typeCheckId = getTypeCheckId(currentType);
        final RadioGroup radioGroupTypeCheck = findViewById(R.id.radioGroupTypeCheck);
        radioGroupTypeCheck.check(typeCheckId);
        radioGroupTypeCheck.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = findViewById(checkedId);
            currentType = (String) rb.getTag();
            initTLogs();
            showList(logVos);
        });

        // 为ListView注册一个监听器，当用户点击了ListView中的任何一个子项时，就会回调onItemClick()方法
        // 在这个方法中可以通过position参数判断出用户点击的是那一个子项
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position <= 0) return;

            LogVo logVo = logVos.get(position - 1);
            logDetail(logVo);
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position <= 0) return false;

            //定义AlertDialog.Builder对象，当长按列表项的时候弹出确认删除对话框
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle(R.string.delete_log_title);
            builder.setMessage(R.string.delete_log_tips);

            //添加AlertDialog.Builder对象的setPositiveButton()方法
            builder.setPositiveButton(R.string.confirm, (dialog, which) -> {
                Long id1 = logVos.get(position - 1).getId();
                Log.d(TAG, "id = " + id1);
                LogUtil.delLog(id1, null);
                initTLogs(); //初始化数据
                showList(logVos);
                Toast.makeText(getBaseContext(), R.string.delete_log_toast, Toast.LENGTH_SHORT).show();
            });

            //添加AlertDialog.Builder对象的setNegativeButton()方法
            builder.setNegativeButton(R.string.cancel, (dialog, which) -> {
            });

            builder.create().show();
            return true;
        });
    }

    private int getTypeCheckId(String currentType) {
        switch (currentType) {
            case "call":
                return R.id.btnTypeCall;
            case "app":
                return R.id.btnTypeApp;
            default:
                return R.id.btnTypeSms;
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);

        //第一次打开，未授权无法获取SIM信息，尝试在此重新获取
        if (MyApplication.SimInfoList.isEmpty()) {
            MyApplication.SimInfoList = PhoneUtils.getSimMultiInfo();
        }
        Log.d(TAG, "SimInfoList = " + MyApplication.SimInfoList.size());
        if (deviceInfoLabel != null) {
            deviceInfoLabel.setText(getFriendlyDeviceName());
        }

        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            boolean needOpenBattery = getSharedPreferences("quick_settings", MODE_PRIVATE)
                    .getBoolean("open_battery_after_optimization", false);
            if (needOpenBattery && KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                getSharedPreferences("quick_settings", MODE_PRIVATE)
                        .edit()
                        .putBoolean("open_battery_after_optimization", false)
                        .apply();
                KeepAliveUtils.openAppBatterySetting(this);
                return;
            }
        }

        //开启读取通知栏权限
        if (SettingUtil.getSwitchEnableAppNotify() && !CommonUtil.isNotificationListenerServiceEnabled(this)) {
            CommonUtil.toggleNotificationListenerService(this);
            SettingUtil.switchEnableAppNotify(false);
            Toast.makeText(this, R.string.tips_notification_listener, Toast.LENGTH_LONG).show();
            return;
        }

        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onResume:", e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onDestroy:", e);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onPause:", e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CommonUtil.NOTIFICATION_REQUEST_CODE) {
            if (CommonUtil.isNotificationListenerServiceEnabled(this)) {
                Toast.makeText(this, R.string.notification_listener_service_enabled, Toast.LENGTH_SHORT).show();
                CommonUtil.toggleNotificationListenerService(this);
            } else {
                Toast.makeText(this, R.string.notification_listener_service_disabled, Toast.LENGTH_SHORT).show();
            }
        }
    }

    // 权限判断相关

    // 初始化数据
    private void initTLogs() {
        logVos = LogUtil.getLog(null, null, currentType);
    }

    private void showList(List<LogVo> logVosN) {
        Log.d(TAG, "showList: " + logVosN);
        if (adapter == null) {
            // 将适配器上的数据传递给listView
            listView = findViewById(R.id.list_view_log);
            listView.setInterface(this);
            adapter = new LogAdapter(MainActivity.this, R.layout.item_log, logVosN);
            listView.setAdapter(adapter);
        } else {
            adapter.onDateChange(logVosN);
        }
    }

    @Override
    public void onRefresh() {
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            // TODO Auto-generated method stub
            //获取最新数据
            initTLogs();
            //通知界面显示
            showList(logVos);
            //通知listview 刷新数据完毕；
            listView.refreshComplete();
        }, 2000);
    }

    public void logDetail(LogVo logVo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.details);
        String simInfo = logVo.getSimInfo();
        if (simInfo != null) {
            builder.setMessage(logVo.getFrom() + "\n\n" + logVo.getContent() + "\n\n" + logVo.getSimInfo() + "\n\n" + logVo.getRule() + "\n\n" + TimeUtil.utc2Local(logVo.getTime()) + "\n\nResponse：" + logVo.getForwardResponse());
        } else {
            builder.setMessage(logVo.getFrom() + "\n\n" + logVo.getContent() + "\n\n" + logVo.getRule() + "\n\n" + TimeUtil.utc2Local(logVo.getTime()) + "\n\nResponse：" + logVo.getForwardResponse());
        }
        //删除
        builder.setNegativeButton(R.string.del, (dialog, which) -> {
            Long id = logVo.getId();
            Log.d(TAG, "id = " + id);
            LogUtil.delLog(id, null);
            initTLogs(); //初始化数据
            showList(logVos);
            Toast.makeText(MainActivity.this, R.string.delete_log_toast, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        builder.show();
    }

    public void toAppList() {
        Intent intent = new Intent(this, AppListActivity.class);
        startActivity(intent);
    }

    public void toClone() {
        Intent intent = new Intent(this, CloneActivity.class);
        startActivity(intent);
    }

    public void toSetting() {
        Intent intent = new Intent(this, SettingActivity.class);
        startActivity(intent);
    }

    public void toAbout() {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }

    public void toHelp() {
        Uri uri = Uri.parse("https://gitee.com/pp/SmsForwarder/wikis/pages");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void toRuleSetting(View view) {
        Intent intent = new Intent(this, RuleActivity.class);
        startActivity(intent);
    }

    public void toSendSetting(View view) {
        Intent intent = new Intent(this, SenderActivity.class);
        startActivity(intent);
    }

    public void cleanLog(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.clear_logs_tips)
                .setPositiveButton(R.string.confirm, (dialog, which) -> {
                    // TODO Auto-generated method stub
                    LogUtil.delLog(null, null);
                    initTLogs();
                    adapter.add(logVos);
                });
        builder.show();
    }

    //按返回键不退出回到桌面
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }

    //启用menu：右上角直接显示设置入口，不再弹出多个菜单
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //menu点击事件
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.to_app_list:
                toAppList();
                return true;
            case R.id.to_clone:
                toClone();
                return true;
            case R.id.to_setting:
                toSetting();
                return true;
            case R.id.to_about:
                toAbout();
                return true;
            case R.id.to_help:
                toHelp();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //设置menu图标显示
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        if (featureId == Window.FEATURE_ACTION_BAR && menu != null) {
            if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
                try {
                    Method m = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);
                    m.setAccessible(true);
                    m.invoke(menu, true);
                } catch (NoSuchMethodException e) {
                    Log.e(TAG, "onMenuOpened", e);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return super.onMenuOpened(featureId, menu);
    }

}
