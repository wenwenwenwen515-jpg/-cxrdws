package your.package.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class ConfirmCleanReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val recordId = intent.getStringExtra("record_id") ?: return

        when (intent.action) {
            "ACTION_CONFIRM_CLEAN_SMS" -> {
                if (!DefaultSmsHelper.isDefaultSmsApp(context)) return
                // TODO: 从本地数据库查 recordId 对应的短信ID。
                // TODO: 只删除本软件记录的“已处理/已转发”短信。
                // 示例：context.contentResolver.delete(Telephony.Sms.CONTENT_URI, "_id=?", arrayOf(smsId))
                // TODO: 写入清理日志。
            }
            "ACTION_KEEP_SMS" -> {
                // TODO: 取消本次清理，写入日志：用户选择保留短信。
            }
        }
    }
}
