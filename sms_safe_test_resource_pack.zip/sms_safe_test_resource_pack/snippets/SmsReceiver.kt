package your.package.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Telephony.Sms.Intents.SMS_DELIVER_ACTION != intent.action) return

        val prefs = context.getSharedPreferences("sms_clean_settings", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("delay_clean_enabled", false)
        val delaySeconds = prefs.getLong("delay_seconds", 120L)

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val from = messages.firstOrNull()?.originatingAddress ?: "unknown"
        val body = messages.joinToString(separator = "") { it.messageBody ?: "" }

        // TODO: 保存短信记录到本地数据库，并标记为“已处理/待确认清理”。
        // 注意：这里不要静默删除短信，只启动提醒任务。
        val localRecordId = System.currentTimeMillis().toString()

        if (enabled && DefaultSmsHelper.isDefaultSmsApp(context)) {
            val request = OneTimeWorkRequestBuilder<SmsCleanReminderWorker>()
                .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
                .setInputData(workDataOf("record_id" to localRecordId, "from" to from, "preview" to body.take(20)))
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
