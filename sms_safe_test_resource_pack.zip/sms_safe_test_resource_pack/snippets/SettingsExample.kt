package your.package.sms

import android.content.Context

object SmsCleanSettings {
    fun setDelayCleanEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences("sms_clean_settings", Context.MODE_PRIVATE)
            .edit().putBoolean("delay_clean_enabled", enabled).apply()
    }

    fun setDelaySeconds(context: Context, seconds: Long) {
        context.getSharedPreferences("sms_clean_settings", Context.MODE_PRIVATE)
            .edit().putLong("delay_seconds", seconds).apply()
    }

    fun getDelaySeconds(context: Context): Long {
        return context.getSharedPreferences("sms_clean_settings", Context.MODE_PRIVATE)
            .getLong("delay_seconds", 120L)
    }
}
