package your.package.sms

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

class SmsCleanReminderWorker(
    context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    override fun doWork(): Result {
        if (!DefaultSmsHelper.isDefaultSmsApp(applicationContext)) return Result.success()

        val recordId = inputData.getString("record_id") ?: return Result.success()
        showReminderNotification(recordId)
        return Result.success()
    }

    private fun showReminderNotification(recordId: String) {
        val channelId = "sms_clean_reminder"
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "短信清理提醒", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        val confirmIntent = Intent(applicationContext, ConfirmCleanReceiver::class.java).apply {
            action = "ACTION_CONFIRM_CLEAN_SMS"
            putExtra("record_id", recordId)
        }
        val keepIntent = Intent(applicationContext, ConfirmCleanReceiver::class.java).apply {
            action = "ACTION_KEEP_SMS"
            putExtra("record_id", recordId)
        }

        val confirmPending = PendingIntent.getBroadcast(applicationContext, recordId.hashCode(), confirmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val keepPending = PendingIntent.getBroadcast(applicationContext, recordId.hashCode() + 1, keepIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("短信清理提醒")
            .setContentText("有短信已到清理时间，是否清理？")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(android.R.drawable.ic_menu_delete, "确认清理", confirmPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "保留短信", keepPending)
            .build()

        manager.notify(recordId.hashCode(), notification)
    }
}
