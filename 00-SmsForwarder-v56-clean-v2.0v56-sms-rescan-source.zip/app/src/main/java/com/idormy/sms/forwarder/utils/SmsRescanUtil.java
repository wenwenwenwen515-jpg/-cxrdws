package com.idormy.sms.forwarder.utils;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.idormy.sms.forwarder.model.vo.SmsVo;
import com.idormy.sms.forwarder.sender.SendUtil;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class SmsRescanUtil {
    private static final String TAG = "SmsRescanUtil";
    private static final String PREF = "sms_rescan_forwarded_v1";
    private static final String KEY_SET = "keys";
    private static final String KEY_INIT = "initialized";
    private static final int MAX_KEEP_KEYS = 300;
    private static final int MAX_SCAN_COUNT = 20;
    private static final long SCAN_WINDOW_MS = 60L * 60L * 1000L; // 只扫最近1小时短信，避免误发太旧短信

    public static void scanAndForward(Context context) {
        try {
            if (context == null) return;
            Context appContext = context.getApplicationContext();

            if (!SettingUtil.getSwitchEnableSms()) {
                return;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "READ_SMS permission not granted, skip rescan");
                return;
            }

            List<SmsVo> recentSms = readRecentInboxSms(appContext);
            if (recentSms.isEmpty()) {
                ensureInitialized(appContext);
                return;
            }

            SharedPreferences sp = appContext.getSharedPreferences(PREF, Context.MODE_PRIVATE);

            // 第一次启动补扫时，只记录当前已有短信，不立刻批量补发旧短信，避免把历史短信全部发出去。
            // 后续新短信会正常补扫补发。
            if (!sp.getBoolean(KEY_INIT, false)) {
                for (SmsVo smsVo : recentSms) {
                    markForwarded(appContext, smsVo);
                }
                sp.edit().putBoolean(KEY_INIT, true).apply();
                Log.i(TAG, "rescan initialized, mark recent sms only");
                return;
            }

            for (int i = recentSms.size() - 1; i >= 0; i--) {
                SmsVo smsVo = recentSms.get(i);
                if (smsVo == null || smsVo.getMobile() == null || smsVo.getContent() == null || smsVo.getDate() == null) {
                    continue;
                }

                if (isForwarded(appContext, smsVo)) {
                    continue;
                }

                Log.i(TAG, "rescan found unforwarded sms: " + smsVo);
                SendUtil.send_msg(appContext, smsVo, 1, "sms");
                markForwarded(appContext, smsVo);
            }
        } catch (Throwable e) {
            Log.e(TAG, "scanAndForward error", e);
        }
    }

    private static void ensureInitialized(Context context) {
        try {
            SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            if (!sp.getBoolean(KEY_INIT, false)) {
                sp.edit().putBoolean(KEY_INIT, true).apply();
            }
        } catch (Throwable ignored) {
        }
    }

    private static List<SmsVo> readRecentInboxSms(Context context) {
        List<SmsVo> list = new ArrayList<>();
        Cursor cursor = null;
        try {
            long minDate = System.currentTimeMillis() - SCAN_WINDOW_MS;
            Uri uri = Uri.parse("content://sms/inbox");
            String[] projection = new String[]{"address", "body", "date"};
            String selection = "date>=?";
            String[] selectionArgs = new String[]{String.valueOf(minDate)};
            String sortOrder = "date DESC";

            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, sortOrder);
            if (cursor == null) return list;

            int addressIndex = cursor.getColumnIndex("address");
            int bodyIndex = cursor.getColumnIndex("body");
            int dateIndex = cursor.getColumnIndex("date");

            int count = 0;
            while (cursor.moveToNext() && count < MAX_SCAN_COUNT) {
                String mobile = addressIndex >= 0 ? cursor.getString(addressIndex) : "";
                String body = bodyIndex >= 0 ? cursor.getString(bodyIndex) : "";
                long dateMs = dateIndex >= 0 ? cursor.getLong(dateIndex) : System.currentTimeMillis();

                if (mobile == null) mobile = "";
                if (body == null) body = "";
                if (body.trim().isEmpty()) continue;

                String simInfo = getDefaultSimInfo();
                list.add(new SmsVo(mobile, body, new Date(dateMs), simInfo));
                count++;
            }
        } catch (Throwable e) {
            Log.e(TAG, "readRecentInboxSms error", e);
        } finally {
            try {
                if (cursor != null) cursor.close();
            } catch (Throwable ignored) {
            }
        }
        return list;
    }

    private static String getDefaultSimInfo() {
        try {
            String extra = SettingUtil.getAddExtraSim1();
            if (extra != null && !extra.isEmpty()) {
                return "SIM1_" + extra;
            }
        } catch (Throwable ignored) {
        }

        try {
            String simInfo = SimUtil.getSimInfo(1);
            if (simInfo != null && !simInfo.isEmpty()) {
                return simInfo;
            }
        } catch (Throwable ignored) {
        }

        return "SIM1";
    }

    public static void markForwarded(Context context, SmsVo smsVo) {
        try {
            if (context == null || smsVo == null) return;
            String key = buildKey(smsVo);
            SharedPreferences sp = context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
            Set<String> old = sp.getStringSet(KEY_SET, new LinkedHashSet<String>());
            LinkedHashSet<String> keys = new LinkedHashSet<>();
            if (old != null) keys.addAll(old);
            keys.add(key);

            while (keys.size() > MAX_KEEP_KEYS) {
                String first = keys.iterator().next();
                keys.remove(first);
            }

            sp.edit().putStringSet(KEY_SET, keys).apply();
        } catch (Throwable e) {
            Log.e(TAG, "markForwarded error", e);
        }
    }

    private static boolean isForwarded(Context context, SmsVo smsVo) {
        try {
            String key = buildKey(smsVo);
            SharedPreferences sp = context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
            Set<String> keys = sp.getStringSet(KEY_SET, new LinkedHashSet<String>());
            return keys != null && keys.contains(key);
        } catch (Throwable e) {
            return false;
        }
    }

    private static String buildKey(SmsVo smsVo) {
        String raw = String.valueOf(smsVo.getMobile()) + "|" +
                (smsVo.getDate() == null ? 0 : smsVo.getDate().getTime()) + "|" +
                String.valueOf(smsVo.getContent());
        return sha256(raw);
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) sb.append('0');
                sb.append(hex);
            }
            return sb.toString();
        } catch (Throwable e) {
            return String.valueOf(value.hashCode());
        }
    }
}
