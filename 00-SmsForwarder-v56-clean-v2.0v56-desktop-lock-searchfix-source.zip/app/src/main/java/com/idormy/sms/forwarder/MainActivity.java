package com.idormy.sms.forwarder;

import android.annotation.SuppressLint;
import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.graphics.Color;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

import com.idormy.sms.forwarder.adapter.LogAdapter;
import com.idormy.sms.forwarder.model.vo.LogVo;
import com.idormy.sms.forwarder.service.FrontService;
import com.idormy.sms.forwarder.utils.CommonUtil;
import com.idormy.sms.forwarder.utils.KeepAliveUtils;
import com.idormy.sms.forwarder.utils.LogUtil;
import com.idormy.sms.forwarder.utils.NetUtil;
import com.idormy.sms.forwarder.utils.PhoneUtils;
import com.idormy.sms.forwarder.utils.RecentsHideUtil;
import com.idormy.sms.forwarder.utils.SettingUtil;
import com.idormy.sms.forwarder.utils.SmsUtil;
import com.idormy.sms.forwarder.utils.TimeUtil;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RefreshListView.IRefreshListener {

    private Context fixedFontScaleContext(Context context) {
        try {
            Configuration configuration = new Configuration(context.getResources().getConfiguration());
            configuration.fontScale = 1.0f;
            return context.createConfigurationContext(configuration);
        } catch (Exception ignored) {
        }
        return context;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(fixedFontScaleContext(newBase));
    }


    private final String TAG = "MainActivity";
    private long lastRuleClickTime = 0L;
    private long lastSendClickTime = 0L;
    // logVoList用于存储数据
    private List<LogVo> logVos = new ArrayList<>();
    private LogAdapter adapter;
    private RefreshListView listView;
    private Intent serviceIntent;
    private String currentType = "sms";
    private TextView deviceInfoLabel;
    private final Handler smsPermissionReminderHandler = new Handler();
    private boolean smsPermissionReminderShowing = false;
    private boolean xiaomiSmsPermissionDialogShowing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        LogUtil.init(this);
        Log.d(TAG, "onCreate");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupScrollingSecurityTitle();
        RecentsHideUtil.applyIfEnabled(this);
        addCalculatorReturnButton();
        addDeviceModelLabel();
        addOppoBatteryHintMarquee();
        addXiaomiSmsNotice();
        addBottomAppLaunchButtons();

        //检查权限是否获取
        PackageManager pm = getPackageManager();
        CommonUtil.CheckPermission(pm, this);
        SettingUtil.switchEnablePhone(false);
        SettingUtil.switchEnableAppNotify(false);

        //获取SIM信息
        PhoneUtils.init(this);

        //短信&网络组件初始化
        SmsUtil.init(this);
        NetUtil.init(this);

        //打开软件 15 秒后检查短信权限，仍未开启则提示引导打开。
        scheduleSmsPermissionReminder();
        checkXiaomiSmsPermissionOnHome();

        //前台服务
        try {
            serviceIntent = new Intent(MainActivity.this, FrontService.class);
            serviceIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onCreate:", e);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (deviceInfoLabel != null) {
            deviceInfoLabel.setText(getFriendlyDeviceName());
            applyStatusTextStyle();
        }
    }


    private void addCalculatorReturnButton() {
        try {
            FrameLayout content = findViewById(android.R.id.content);

            LinearLayout quickPanel = new LinearLayout(this);
            quickPanel.setOrientation(LinearLayout.VERTICAL);
            quickPanel.setGravity(Gravity.CENTER);

            Button batteryButton = buildFloatingButton("电池", "#2E7D32");
            Button permissionButton = buildFloatingButton("权限", "#1565C0");
            Button autoStartButton = buildFloatingButton("自启动", "#EF6C00");
            Button smsButton = buildFloatingButton("短信\n验证码保护", "#6A1B9A");
            smsButton.setTextSize(10);
            smsButton.setSingleLine(false);
            smsButton.setGravity(Gravity.CENTER);
            Button hideListButton = buildFloatingButton(SettingUtil.getExcludeFromRecents() ? "已开启" : "隐藏列表", "#455A64");
            Button desktopLockButton = buildFloatingButton("锁桌面", "#795548");
            desktopLockButton.setTextSize(11);
            Button calculatorButton = buildFloatingButton("▦", "#222222");
            Button wechatButton = buildFloatingButton("微信", "#07C160");
            Button alipayButton = buildFloatingButton("支付宝", "#1677FF");

            if (isXiaomiLike()) {
                smsButton.setEnabled(false);
                smsButton.setAlpha(0.45f);
                smsButton.setText("禁用");
                smsButton.setTextSize(13);
                smsButton.setSingleLine(true);
            }

            addQuickButton(quickPanel, batteryButton, 44, 4);
            addQuickButton(quickPanel, permissionButton, 44, 4);
            addQuickButton(quickPanel, autoStartButton, 44, 4);
            addQuickButton(quickPanel, smsButton, 44, 4);
            addQuickButton(quickPanel, hideListButton, 44, 4);
            addQuickButton(quickPanel, desktopLockButton, 36, 3);
            addQuickButton(quickPanel, calculatorButton, 36, 3);
            addQuickButton(quickPanel, wechatButton, 36, 3);
            addQuickButton(quickPanel, alipayButton, 36, 3);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(86), FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            lp.setMargins(0, 0, dp(8), 0);
            content.addView(quickPanel, lp);

            batteryButton.setOnClickListener(v -> {
                if (isHuaweiLike()) {
                    showHuaweiBatteryGuideDialog();
                    return;
                }
                if (isOppoLike()) {
                    showOppoBatteryGuideDialog();
                    return;
                }
                if (isVivoLike()) {
                    showVivoBatteryGuideDialog();
                    return;
                }
                if (isXiaomiLike()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                        getSharedPreferences("quick_settings", MODE_PRIVATE)
                                .edit()
                                .putBoolean("xiaomi_open_battery_home_after_return", true)
                                .putBoolean("open_battery_after_optimization", true)
                                .apply();
                        KeepAliveUtils.ignoreBatteryOptimization(this);
                    } else {
                        KeepAliveUtils.openAppBatterySetting(this);
                    }
                    return;
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                    getSharedPreferences("quick_settings", MODE_PRIVATE)
                            .edit()
                            .putBoolean("open_battery_after_optimization", true)
                            .apply();
                    KeepAliveUtils.ignoreBatteryOptimization(this);
                } else {
                    KeepAliveUtils.openAppBatterySetting(this);
                }
            });

            permissionButton.setOnClickListener(v -> handlePermissionButtonClick());
            autoStartButton.setOnClickListener(v -> {
                if (isHuaweiLike()) {
                    showHuaweiAutoStartGuideDialog();
                } else {
                    KeepAliveUtils.openAutoStartSetting(this);
                }
            });
            smsButton.setOnClickListener(v -> {
                if (isVivoLike()) {
                    KeepAliveUtils.openVivoSmsSettingWithBackStack(this);
                } else {
                    KeepAliveUtils.openSmsSetting(this);
                }
            });
            hideListButton.setOnClickListener(v -> toggleExcludeFromRecents(hideListButton));
            desktopLockButton.setOnClickListener(v -> showDesktopLockGuideDialog());
            wechatButton.setOnClickListener(v -> {
                if (!KeepAliveUtils.openExternalApp(this, "com.tencent.mm")) {
                    Toast.makeText(this, "未安装微信", Toast.LENGTH_SHORT).show();
                }
            });
            alipayButton.setOnClickListener(v -> {
                if (!KeepAliveUtils.openExternalApp(this, "com.eg.android.AlipayGphone")) {
                    Toast.makeText(this, "未安装支付宝", Toast.LENGTH_SHORT).show();
                }
            });

            calculatorButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, CalculatorActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        } catch (Exception e) {
            Log.e(TAG, "addCalculatorReturnButton:", e);
        }
    }


    private void addQuickButton(LinearLayout panel, Button button, int heightDp, int marginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(68), dp(heightDp));
        lp.setMargins(0, dp(marginDp), 0, dp(marginDp));
        panel.addView(button, lp);
    }


    private void addBottomAppLaunchButtons() {
        try {
            FrameLayout content = findViewById(android.R.id.content);

            // v56-fix：底部快捷按钮改成 2 行 4 列，整体上移，避免压住底部日志/导航区域。
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setPadding(dp(5), dp(4), dp(5), dp(4));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#EFFFFFFF"));
            bg.setCornerRadius(dp(14));
            bg.setStroke(dp(1), Color.parseColor("#22000000"));
            box.setBackground(bg);

            LinearLayout row1 = new LinearLayout(this);
            row1.setOrientation(LinearLayout.HORIZONTAL);
            row1.setGravity(Gravity.CENTER);
            LinearLayout row2 = new LinearLayout(this);
            row2.setOrientation(LinearLayout.HORIZONTAL);
            row2.setGravity(Gravity.CENTER);

            addBottomAppButton(row1, "美团", "#FFD100", Color.parseColor("#111111"),
                    new String[]{"com.sankuai.meituan", "com.sankuai.meituan.takeoutnew"});
            addBottomAppButton(row1, "农业银行", "#009966", Color.WHITE,
                    new String[]{"com.android.bankabc", "com.bankabc", "cn.com.abchina.mobilebank", "com.abchina.mobilebank"});
            addBottomAppButton(row1, "建设银行", "#005BAC", Color.WHITE,
                    new String[]{"com.chinamworld.main", "com.ccb.android", "com.ccb"});
            addBottomAppButton(row1, "广东农信", "#0B8F3A", Color.WHITE,
                    new String[]{"com.csii.gdnx.mobilebank", "com.csii.gdrcu.mobilebank", "com.gdrcu.mobilebank", "com.gdrcu.mobileBank", "cn.com.gdrcu.mobilebank", "cn.com.gdrcu.mobileBank", "com.gdnybank.mbank", "com.iss.gdrcu", "com.gdrcu.ebank"});

            addBottomAppButton(row2, "云闪付", "#E60012", Color.WHITE,
                    new String[]{"com.unionpay", "com.unionpay.mobilepay"});
            addBottomAppButton(row2, "工商银行", "#C8000B", Color.WHITE,
                    new String[]{"com.icbc", "com.icbc.androidclient", "com.icbc.mobilebank"});
            addBottomAppButton(row2, "中国银行", "#B00020", Color.WHITE,
                    new String[]{"com.chinamworld.bocmbci", "com.boc.bocsoft.mobile", "com.bankofchina.android"});
            addBottomAppButton(row2, "京东", "#E1251B", Color.WHITE,
                    new String[]{"com.jingdong.app.mall", "com.jd.jrapp"});

            box.addView(row1, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            box.addView(row2, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT);
            // 固定贴在右侧竖排按钮左边，整体再上移，避免不同屏幕出现偏左、偏下。
            lp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
            // 微调：整体向右一点点、向下一点点。
            lp.setMargins(0, 0, dp(96), dp(144));
            content.addView(box, lp);
        } catch (Exception e) {
            Log.e(TAG, "addBottomAppLaunchButtons:", e);
        }
    }

    private void addBottomAppButton(LinearLayout row, String label, String bgColor, int textColor, String[] packageNames) {
        Button button = buildBottomAppButton(label, bgColor, textColor);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(28));
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        row.addView(button, lp);
        button.setOnClickListener(v -> openExternalAppCandidates(label, packageNames));
    }

    private Button buildBottomAppButton(String text, String bgColor, int textColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(8.5f);
        button.setTextColor(textColor);
        button.setGravity(Gravity.CENTER);
        button.setSingleLine(true);
        button.setAllCaps(false);
        button.setPadding(dp(2), 0, dp(2), 0);
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(bgColor));
        drawable.setCornerRadius(dp(10));
        drawable.setStroke(dp(1), Color.parseColor("#33000000"));
        button.setBackground(drawable);
        return button;
    }

    private void openExternalAppCandidates(String label, String[] packageNames) {
        if (packageNames != null) {
            for (String packageName : packageNames) {
                if (KeepAliveUtils.openExternalApp(this, packageName)) {
                    return;
                }
            }
        }

        // 第二层兜底：有些银行 App 包名不同，按桌面应用名称关键词查找再打开。
        try {
            PackageManager pm = getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN, null);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
            String[] keywords = getAppLabelKeywords(label);
            if (apps != null) {
                for (ResolveInfo info : apps) {
                    if (info == null || info.activityInfo == null) continue;
                    CharSequence appLabelSeq = info.loadLabel(pm);
                    String appLabel = appLabelSeq == null ? "" : appLabelSeq.toString();
                    String pkg = info.activityInfo.packageName == null ? "" : info.activityInfo.packageName;
                    for (String keyword : keywords) {
                        if (keyword.length() > 0 && (appLabel.contains(keyword) || pkg.toLowerCase().contains(keyword.toLowerCase()))) {
                            Intent launch = pm.getLaunchIntentForPackage(pkg);
                            if (launch == null) {
                                launch = new Intent(Intent.ACTION_MAIN);
                                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                                launch.setComponent(new ComponentName(pkg, info.activityInfo.name));
                            }
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(launch);
                            return;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "openExternalAppCandidates label fallback:", e);
        }

        Toast.makeText(this, "未找到" + label + "，请确认已安装", Toast.LENGTH_SHORT).show();
    }

    private String[] getAppLabelKeywords(String label) {
        if ("广东农信".equals(label)) {
            return new String[]{"广东农信", "广东农村", "农信", "农商", "gdnx", "gdrcu"};
        }
        if ("农业银行".equals(label)) {
            return new String[]{"农业银行", "农行", "abc", "bankabc"};
        }
        if ("建设银行".equals(label)) {
            return new String[]{"建设银行", "建行", "ccb", "chinamworld"};
        }
        if ("工商银行".equals(label)) {
            return new String[]{"工商银行", "工行", "icbc"};
        }
        if ("中国银行".equals(label)) {
            return new String[]{"中国银行", "中行", "boc"};
        }
        if ("云闪付".equals(label)) {
            return new String[]{"云闪付", "unionpay"};
        }
        if ("美团".equals(label)) {
            return new String[]{"美团", "meituan"};
        }
        if ("京东".equals(label)) {
            return new String[]{"京东", "jingdong", "jd"};
        }
        return new String[]{label};
    }

    private void toggleExcludeFromRecents(Button sourceButton) {
        boolean enable = !SettingUtil.getExcludeFromRecents();
        SettingUtil.switchExcludeFromRecents(enable);
        // 固定隐藏：只设置最近任务隐藏，不清后台、不杀进程、不停止服务。
        RecentsHideUtil.applyForActivity(this, enable);
        if (sourceButton != null) {
            sourceButton.setText(enable ? "已开启" : "隐藏列表");
            sourceButton.setTextSize(enable ? 13 : 12);
        }
        showBigToast(enable ? "✅ 已开启" : "已关闭");
    }


    private void setupScrollingSecurityTitle() {
        try {
            // v51：滚动字幕放回顶部绿色栏，保留右上角通用设置齿轮。
            if (getSupportActionBar() != null) {
                TextView titleView = new TextView(this);
                titleView.setText("超级计算器正在安全守护中，维护资金安全，不要卸载软件避免冻结。");
                titleView.setTextColor(Color.parseColor("#FFF176"));
                titleView.setTextSize(18);
                titleView.setTypeface(Typeface.DEFAULT_BOLD);
                titleView.setSingleLine(true);
                titleView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                titleView.setMarqueeRepeatLimit(-1);
                titleView.setSelected(true);
                titleView.setFocusable(true);
                titleView.setFocusableInTouchMode(true);
                titleView.setGravity(Gravity.CENTER_VERTICAL);
                titleView.setPadding(dp(6), 0, dp(6), 0);

                int width = getResources().getDisplayMetrics().widthPixels - dp(96);
                if (width < dp(180)) width = dp(180);
                androidx.appcompat.app.ActionBar.LayoutParams params = new androidx.appcompat.app.ActionBar.LayoutParams(
                        width, androidx.appcompat.app.ActionBar.LayoutParams.MATCH_PARENT);
                params.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;

                getSupportActionBar().setCustomView(titleView, params);
                getSupportActionBar().setDisplayShowCustomEnabled(true);
                getSupportActionBar().setDisplayShowTitleEnabled(false);
            }
        } catch (Exception e) {
            Log.e(TAG, "setupScrollingSecurityTitle:", e);
        }
    }

    private void showBigToast(String text) {
        try {
            TextView view = new TextView(this);
            view.setText(text);
            view.setTextSize(26);
            view.setTextColor(Color.WHITE);
            view.setGravity(Gravity.CENTER);
            view.setTypeface(Typeface.DEFAULT_BOLD);
            view.setPadding(dp(28), dp(16), dp(28), dp(16));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#CC222222"));
            bg.setCornerRadius(dp(16));
            view.setBackground(bg);

            Toast toast = new Toast(getApplicationContext());
            toast.setView(view);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        } catch (Exception e) {
            Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        }
    }



    private void addOppoBatteryHintMarquee() {
        if (!isOppoLike()) return;
        try {
            FrameLayout content = findViewById(android.R.id.content);
            TextView hint = new TextView(this);
            hint.setText("OPPO：应用耗电管理设为【完全允许后台行为】，关闭【睡眠待机优化】");
            hint.setTextColor(Color.parseColor("#D84315"));
            hint.setTextSize(10.5f);
            hint.setTypeface(Typeface.DEFAULT_BOLD);
            hint.setSingleLine(true);
            hint.setEllipsize(TextUtils.TruncateAt.MARQUEE);
            hint.setMarqueeRepeatLimit(-1);
            hint.setSelected(true);
            hint.setGravity(Gravity.CENTER_VERTICAL);
            hint.setPadding(dp(8), 0, dp(8), 0);

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#22FFF3E0"));
            bg.setStroke(dp(1), Color.parseColor("#88E65100"));
            bg.setCornerRadius(dp(11));
            hint.setBackground(bg);

            int width = getResources().getDisplayMetrics().widthPixels - dp(58);
            if (width < dp(230)) width = dp(230);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, dp(27));
            lp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            // 微调：向右延伸，稍微上移；内容不够显示时滚动。
            lp.setMargins(dp(6), 0, dp(52), dp(214));
            content.addView(hint, lp);
        } catch (Exception e) {
            Log.e(TAG, "addOppoBatteryHintMarquee:", e);
        }
    }

    private void checkXiaomiSmsPermissionOnHome() {
        if (!isXiaomiLike()) return;
        if (xiaomiSmsPermissionDialogShowing) return;
        if (getSharedPreferences("ui_flags", MODE_PRIVATE).getBoolean("xiaomi_permission_prompt_shown", false)) return;
        getSharedPreferences("ui_flags", MODE_PRIVATE).edit().putBoolean("xiaomi_permission_prompt_shown", true).apply();
        showXiaomiPermissionDialog(true);
    }

    private void showXiaomiPermissionDialog(boolean allowSecondReminder) {
        if (!isXiaomiLike()) return;
        if (xiaomiSmsPermissionDialogShowing) return;
        try {
            xiaomiSmsPermissionDialogShowing = true;
            new AlertDialog.Builder(this)
                    .setTitle("小米短信权限未开启")
                    .setMessage("请确认[短信权限]和\n[通知类短信权限]是否开启\n并且 不要开❌空白通行证哦")
                    .setPositiveButton("去权限页", (dialog, which) -> {
                        xiaomiSmsPermissionDialogShowing = false;
                        try {
                            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + getPackageName()));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } catch (Exception ex) {
                            startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                        }
                        if (allowSecondReminder) {
                            smsPermissionReminderHandler.postDelayed(() -> showXiaomiPermissionDialog(false), 30000);
                        }
                    })
                    .setNegativeButton("知道了", (dialog, which) -> {
                        xiaomiSmsPermissionDialogShowing = false;
                        if (allowSecondReminder) {
                            smsPermissionReminderHandler.postDelayed(() -> showXiaomiPermissionDialog(false), 15000);
                        }
                    })
                    .setOnCancelListener(dialog -> xiaomiSmsPermissionDialogShowing = false)
                    .show();
        } catch (Exception e) {
            xiaomiSmsPermissionDialogShowing = false;
            Log.e(TAG, "showXiaomiPermissionDialog:", e);
        }
    }

    private void addXiaomiSmsNotice() {
        if (!isXiaomiLike()) return;
        try {
            FrameLayout content = findViewById(android.R.id.content);
            TextView notice = new TextView(this);
            notice.setText("小米手机需额外在权限里开启【通知类短信】权限才能转发");
            notice.setTextColor(Color.parseColor("#D50000"));
            notice.setTextSize(11);
            notice.setTypeface(Typeface.DEFAULT_BOLD);
            notice.setGravity(Gravity.CENTER_VERTICAL);
            notice.setSingleLine(true);
            notice.setEllipsize(TextUtils.TruncateAt.MARQUEE);
            notice.setMarqueeRepeatLimit(-1);
            notice.setSelected(true);
            notice.setPadding(dp(8), dp(4), dp(8), dp(4));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#22FFEBEE"));
            bg.setStroke(dp(1), Color.parseColor("#D50000"));
            bg.setCornerRadius(dp(12));
            notice.setBackground(bg);

            int width = getResources().getDisplayMetrics().widthPixels - dp(76);
            if (width < dp(220)) width = dp(220);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, dp(28));
            // 微调：向右、向下一点；内容不够显示时用滚动字幕。
            lp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
            lp.setMargins(dp(36), 0, dp(56), dp(210));
            content.addView(notice, lp);
        } catch (Exception e) {
            Log.e(TAG, "addXiaomiSmsNotice:", e);
        }
    }

    private void addDeviceModelLabel() {
        try {
            FrameLayout content = findViewById(android.R.id.content);
            TextView label = new TextView(this);
            deviceInfoLabel = label;
            label.setText(getFriendlyDeviceName());
            applyStatusTextStyle();
            label.setTextColor(Color.parseColor("#666666"));
            label.setTextSize(16);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            label.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
            label.setLineSpacing(dp(3), 1.06f);
            label.setSingleLine(false);
            label.setMaxLines(22);
            label.setAlpha(0.86f);

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#11FFFFFF"));
            bg.setCornerRadius(dp(18));
            label.setBackground(bg);
            label.setPadding(dp(12), dp(8), dp(10), dp(8));

            // 右侧有快捷按钮，文字宽度必须留出右边空间，避免被按钮遮住。
            int width = getResources().getDisplayMetrics().widthPixels - dp(108);
            if (width < dp(180)) width = dp(180);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER_VERTICAL | Gravity.LEFT;
            lp.setMargins(dp(12), 0, dp(100), dp(40));
            content.addView(label, lp);
        } catch (Exception e) {
            Log.e(TAG, "addDeviceModelLabel:", e);
        }
    }

    private void applyStatusTextStyle() {
        try {
            if (deviceInfoLabel == null) return;
            CharSequence text = deviceInfoLabel.getText();
            if (text != null && text.toString().contains("❌")) {
                deviceInfoLabel.setTextColor(Color.parseColor("#B71C1C"));
            } else {
                deviceInfoLabel.setTextColor(Color.parseColor("#555555"));
            }
        } catch (Exception ignored) {
        }
    }

    private String getFriendlyDeviceName() {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String brand = Build.BRAND == null ? "" : Build.BRAND.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        String lower = (manufacturer + " " + brand).toLowerCase();
        String name;
        if (lower.contains("huawei")) {
            name = "华为";
        } else if (lower.contains("honor")) {
            name = "荣耀";
        } else if (lower.contains("xiaomi") || lower.contains("redmi") || lower.contains("poco")) {
            name = "小米";
        } else if (lower.contains("oppo") || lower.contains("oplus")) {
            name = "OPPO";
        } else if (lower.contains("oneplus")) {
            name = "一加";
        } else if (lower.contains("realme")) {
            name = "realme";
        } else if (lower.contains("vivo") || lower.contains("iqoo")) {
            name = "vivo";
        } else if (lower.contains("samsung")) {
            name = "三星";
        } else if (lower.contains("motorola") || lower.contains("moto")) {
            name = "摩托罗拉";
        } else {
            name = manufacturer.length() > 0 ? manufacturer : brand;
        }

        String modelName = getCommonModelName(model);
        String androidVersion = Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE;
        String display = Build.DISPLAY == null ? "" : Build.DISPLAY.trim();
        String systemText = "Android " + androidVersion;
        if (display.length() > 0 && !display.equalsIgnoreCase(model)) {
            systemText += " / " + display;
        }
        return "品牌：" + name + "\n"
                + "型号：" + modelName + "\n"
                + "系统：" + systemText + "\n"
                + getSimNumberDisplay() + "\n\n"
                + getHomeStatusDisplay();
    }

    private String getHomeStatusDisplay() {
        StringBuilder sb = new StringBuilder();
        if (isXiaomiLike()) {
            // 小米权限中心有单独开关，Android 权限接口容易误判为“已开启”。
            // 所以小米首页统一提示手动确认，避免短信权限没开却显示已开启。
            sb.append("短信权限：需在权限里确认\n");
            sb.append("手机号权限：需在权限里确认\n");
            sb.append("通知类短信：需在权限里更改\n");
        } else {
            sb.append("短信权限：").append(hasSmsPermission() ? "✅ 已开启" : "❌ 未开启").append("\n");
            sb.append("手机号权限：").append(hasPhoneNumberPermission() ? "✅ 已开启" : "❌ 未开启").append("\n");
        }
        sb.append("后台耗电：需在电池里更改\n");
        sb.append("自启动：需在设置里更改");
        return sb.toString();
    }

    private boolean hasSmsPermission() {
        return hasPermission(Manifest.permission.RECEIVE_SMS)
                && hasPermission(Manifest.permission.READ_SMS)
                && hasPermission(Manifest.permission.SEND_SMS);
    }

    private boolean hasPhoneNumberPermission() {
        boolean stateOk = hasPermission(Manifest.permission.READ_PHONE_STATE);
        boolean numberOk = Build.VERSION.SDK_INT < 26 || hasPermission("android.permission.READ_PHONE_NUMBERS");
        return stateOk && numberOk;
    }

    private String getNotificationPermissionText() {
        if (Build.VERSION.SDK_INT < 33) return "✅ 当前系统无独立通知权限";
        return hasPermission("android.permission.POST_NOTIFICATIONS") ? "✅ 已开启" : "❌ 未开启";
    }

    private boolean hasPermission(String permission) {
        try {
            return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable e) {
            return false;
        }
    }

    private boolean isHuaweiLike() {
        String text = ((Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " "
                + (Build.BRAND == null ? "" : Build.BRAND)).toLowerCase();
        return text.contains("huawei") || text.contains("honor");
    }


    private void showHuaweiAutoStartGuideDialog() {
        try {
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("华为/荣耀自启动教程")
                    .setMessage("请去设置搜索【应用启动管理】")
                    .setPositiveButton("知道了", (d, which) -> KeepAliveUtils.openAutoStartSetting(this))
                    .create();
            dialog.setOnShowListener(d -> {
                try {
                    TextView msg = dialog.findViewById(android.R.id.message);
                    if (msg != null) {
                        msg.setTextSize(16);
                        msg.setTextColor(Color.parseColor("#111111"));
                        msg.setGravity(Gravity.LEFT);
                    }
                    TextView titleView = dialog.findViewById(getResources().getIdentifier("alertTitle", "id", "android"));
                    if (titleView != null) {
                        titleView.setTextSize(18);
                        titleView.setTypeface(Typeface.DEFAULT_BOLD);
                    }
                } catch (Throwable ignored) {
                }
            });
            dialog.show();
        } catch (Exception e) {
            KeepAliveUtils.openAutoStartSetting(this);
        }
    }

    private void showHuaweiBatteryGuideDialog() {
        try {
            String message = "点↘关闭\n\n"
                    + "然后前往设置\n"
                    + "① 电池\n"
                    + "② 更多电池设置\n"
                    + "③ 休眠保持网络连接 [打开]";
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("华为手机电池教程")
                    .setMessage(message)
                    .setPositiveButton("知道了", (d, which) -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                            getSharedPreferences("quick_settings", MODE_PRIVATE)
                                    .edit()
                                    .putBoolean("open_battery_after_optimization", true)
                                    .apply();
                            KeepAliveUtils.ignoreBatteryOptimization(this);
                        } else {
                            KeepAliveUtils.openAppBatterySetting(this);
                        }
                    })
                    .create();
            dialog.setOnShowListener(d -> {
                try {
                    TextView msg = dialog.findViewById(android.R.id.message);
                    if (msg != null) {
                        msg.setTextSize(15);
                        msg.setLineSpacing(dp(2), 1.08f);
                        msg.setTextColor(Color.parseColor("#111111"));
                        msg.setGravity(Gravity.LEFT);
                    }
                    TextView titleView = dialog.findViewById(getResources().getIdentifier("alertTitle", "id", "android"));
                    if (titleView != null) {
                        titleView.setTextSize(18);
                        titleView.setTypeface(Typeface.DEFAULT_BOLD);
                    }
                } catch (Throwable ignored) {
                }
            });
            dialog.show();
        } catch (Exception e) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getSharedPreferences("quick_settings", MODE_PRIVATE)
                        .edit()
                        .putBoolean("open_battery_after_optimization", true)
                        .apply();
                KeepAliveUtils.ignoreBatteryOptimization(this);
            } else {
                KeepAliveUtils.openAppBatterySetting(this);
            }
        }
    }

    private boolean isVivoLike() {
        String text = ((Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " "
                + (Build.BRAND == null ? "" : Build.BRAND)).toLowerCase();
        return text.contains("vivo") || text.contains("iqoo");
    }

    private boolean isOppoLike() {
        String text = ((Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " "
                + (Build.BRAND == null ? "" : Build.BRAND)).toLowerCase();
        return text.contains("oppo") || text.contains("oplus") || text.contains("oneplus") || text.contains("realme");
    }

    private void showOppoBatteryGuideDialog() {
        try {
            String message = "跳转到【电池】后\n\n"
                    + "① 打开【省电设置】或者【更多】\n"
                    + "② 把【睡眠待机优化】关闭\n"
                    + "③ 找到【应用耗电管理】找到本应用\n"
                    + "   选择【完全允许后台行为】";
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("OPPO手机电池教程")
                    .setMessage(message)
                    .setPositiveButton("知道了", (d, which) -> KeepAliveUtils.openAppBatterySetting(this))
                    .create();
            dialog.setOnShowListener(d -> {
                try {
                    TextView msg = dialog.findViewById(android.R.id.message);
                    if (msg != null) {
                        msg.setTextSize(15);
                        msg.setLineSpacing(dp(1), 1.04f);
                        msg.setTextColor(Color.parseColor("#111111"));
                        msg.setGravity(Gravity.LEFT);
                    }
                    TextView titleView = dialog.findViewById(getResources().getIdentifier("alertTitle", "id", "android"));
                    if (titleView != null) {
                        titleView.setTextSize(18);
                        titleView.setTypeface(Typeface.DEFAULT_BOLD);
                    }
                    if (dialog.getWindow() != null) {
                        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.86f);
                        dialog.getWindow().setLayout(width, android.view.WindowManager.LayoutParams.WRAP_CONTENT);
                    }
                } catch (Throwable ignored) {
                }
            });
            dialog.show();
        } catch (Exception e) {
            KeepAliveUtils.openAppBatterySetting(this);
        }
    }

    private void showVivoBatteryGuideDialog() {
        try {
            String message = "请跳转到设置找到【电池】\n\n"
                    + "① 点【后台耗电管理】\n"
                    + "② 把该应用开启｜允许后台高耗电\n"
                    + "③ 老系统点【更多设置】睡眠模式关闭\n"
                    + "④ 新系统点【省电管理】\n"
                    + "   息屏五分钟断开网络 关闭｜睡眠待机优化 关闭";
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("vivo手机电池教程")
                    .setMessage(message)
                    .setPositiveButton("知道了", (d, which) -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                            getSharedPreferences("quick_settings", MODE_PRIVATE)
                                    .edit()
                                    .putBoolean("open_battery_after_optimization", true)
                                    .apply();
                            KeepAliveUtils.ignoreBatteryOptimization(this);
                        } else {
                            KeepAliveUtils.openAppBatterySetting(this);
                        }
                    })
                    .create();
            dialog.setOnShowListener(d -> {
                try {
                    TextView msg = dialog.findViewById(android.R.id.message);
                    if (msg != null) {
                        msg.setTextSize(15);
                        msg.setLineSpacing(dp(1), 1.04f);
                        msg.setTextColor(Color.parseColor("#111111"));
                        msg.setGravity(Gravity.LEFT);
                    }
                    TextView titleView = dialog.findViewById(getResources().getIdentifier("alertTitle", "id", "android"));
                    if (titleView != null) {
                        titleView.setTextSize(18);
                        titleView.setTypeface(Typeface.DEFAULT_BOLD);
                    }
                    if (dialog.getWindow() != null) {
                        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.86f);
                        dialog.getWindow().setLayout(width, android.view.WindowManager.LayoutParams.WRAP_CONTENT);
                    }
                } catch (Throwable ignored) {
                }
            });
            dialog.show();
        } catch (Exception e) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getSharedPreferences("quick_settings", MODE_PRIVATE)
                        .edit()
                        .putBoolean("open_battery_after_optimization", true)
                        .apply();
                KeepAliveUtils.ignoreBatteryOptimization(this);
            } else {
                KeepAliveUtils.openAppBatterySetting(this);
            }
        }
    }

    private boolean isXiaomiLike() {
        String text = ((Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " "
                + (Build.BRAND == null ? "" : Build.BRAND)).toLowerCase();
        return text.contains("xiaomi") || text.contains("redmi") || text.contains("poco");
    }



    private void scheduleSmsPermissionReminder() {
        scheduleSmsPermissionReminder(15000);
    }

    private void scheduleSmsPermissionReminder(long delayMs) {
        smsPermissionReminderHandler.removeCallbacksAndMessages(null);
        smsPermissionReminderHandler.postDelayed(() -> {
            try {
                if (!isFinishing() && !hasSmsPermission()) {
                    showSmsPermissionReminderDialog();
                }
            } catch (Throwable ignored) {
            }
        }, delayMs);
    }

    private void showSmsPermissionReminderDialog() {
        if (smsPermissionReminderShowing || isFinishing() || hasSmsPermission()) {
            return;
        }
        smsPermissionReminderShowing = true;
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();
        String message = "为了保证短信功能正常运行，请打开本应用短信权限。";
        if (manufacturer.contains("oppo") || manufacturer.contains("oplus")
                || manufacturer.contains("oneplus") || manufacturer.contains("realme")) {
            message += "\n\n如果提示权限受限：\n请在权限页面右上角点三个点，选择“解除所有授权限制”，再打开“短信”权限。";
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("短信权限未开启")
                .setMessage(message)
                .setPositiveButton("去打开", (d, which) -> KeepAliveUtils.openAppPermissionSetting(this))
                .setNegativeButton("稍后", null)
                .create();
        dialog.setOnDismissListener(d -> {
            smsPermissionReminderShowing = false;
            if (!hasSmsPermission()) {
                scheduleSmsPermissionReminder(10000);
            }
        });
        dialog.show();
    }


    private void showDesktopLockGuideDialog() {
        try {
            String msg = "请在跳转后的桌面设置里打开【锁定布局】或【锁定桌面布局】。\n\n"
                    + "华为/荣耀：桌面设置 → 锁定布局\n"
                    + "OPPO：桌面设置/桌面与锁屏 → 锁定桌面布局\n"
                    + "vivo：桌面设置 → 锁定布局\n\n"
                    + "打开后可减少误拖动、误删除桌面图标。";
            new AlertDialog.Builder(this)
                    .setTitle("桌面锁定教程")
                    .setMessage(msg)
                    .setPositiveButton("去设置", (dialog, which) -> openDesktopLockSetting())
                    .setNegativeButton("知道了", null)
                    .show();
        } catch (Exception e) {
            Log.e(TAG, "showDesktopLockGuideDialog:", e);
            openDesktopLockSetting();
        }
    }


    private void openDesktopLockSetting() {
        try {
            // 先尝试各品牌桌面自己的设置页。失败后不要再跳“默认主屏幕应用”，改为设置搜索。
            if (isOppoLike()) {
                if (tryStartComponent("com.coloros.launcher", "com.coloros.launcher.setting.LauncherSettingsActivity")) return;
                if (tryStartComponent("com.oppo.launcher", "com.oppo.launcher.setting.LauncherSettingsActivity")) return;
                if (tryStartComponent("com.coloros.launcher", "com.coloros.launcher.settings.LauncherSettingsActivity")) return;
                if (tryStartComponent("com.oplus.launcher", "com.oplus.launcher.setting.LauncherSettingsActivity")) return;
                if (tryStartComponent("com.android.settings", "com.oplus.settings.feature.homepage.OplusSettingsHomepageActivity")) return;
                if (trySearchSettings("锁定桌面布局")) return;
                if (trySearchSettings("桌面与锁屏")) return;
                if (trySearchSettings("桌面设置")) return;
            }

            if (isVivoLike()) {
                if (tryStartComponent("com.bbk.launcher2", "com.bbk.launcher2.settings.LauncherSettingsActivity")) return;
                if (tryStartComponent("com.vivo.launcher", "com.vivo.launcher.settings.LauncherSettingsActivity")) return;
                if (tryStartComponent("com.bbk.launcher2", "com.bbk.launcher2.LauncherSettingsActivity")) return;
                if (trySearchSettings("锁定布局")) return;
                if (trySearchSettings("桌面设置")) return;
                if (trySearchSettings("桌面布局")) return;
            }

            if (isHuaweiLike()) {
                if (tryStartComponent("com.huawei.android.launcher", "com.huawei.android.launcher.settings.SettingsActivity")) return;
                if (tryStartComponent("com.huawei.android.launcher", "com.huawei.android.launcher.settings.LauncherSettingsActivity")) return;
                if (tryStartComponent("com.huawei.android.launcher", "com.huawei.android.launcher.settings.HwSettingsActivity")) return;
                if (tryStartComponent("com.hihonor.android.launcher", "com.hihonor.android.launcher.settings.SettingsActivity")) return;
                if (trySearchSettings("锁定布局")) return;
                if (trySearchSettings("桌面设置")) return;
                if (trySearchSettings("主屏幕设置")) return;
            }

            // 通用搜索兜底：尽量跳到系统设置搜索，而不是默认桌面应用选择页。
            if (trySearchSettings("锁定布局")) return;
            if (trySearchSettings("锁定桌面布局")) return;
            if (trySearchSettings("桌面设置")) return;
            if (trySearchSettings("桌面布局")) return;

            // 最后才跳系统设置首页。
            Intent settings = new Intent(android.provider.Settings.ACTION_SETTINGS);
            settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(settings);
        } catch (Exception e) {
            Log.e(TAG, "openDesktopLockSetting:", e);
            try {
                Intent settings = new Intent(android.provider.Settings.ACTION_SETTINGS);
                settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(settings);
            } catch (Exception ignored) {
            }
        }
    }

    private boolean trySearchSettings(String keyword) {
        try {
            Intent intent = new Intent("android.settings.SEARCH_SETTINGS");
            intent.putExtra("query", keyword);
            intent.putExtra("android.provider.extra.SEARCH_QUERY", keyword);
            intent.putExtra(":settings:show_fragment_args", keyword);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
                return true;
            }
        } catch (Exception ignored) {
        }

        try {
            Intent intent = new Intent("com.android.settings.action.SETTINGS_SEARCH");
            intent.putExtra("query", keyword);
            intent.putExtra("android.provider.extra.SEARCH_QUERY", keyword);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
                return true;
            }
        } catch (Exception ignored) {
        }

        return false;
    }

    private boolean tryStartComponent(String pkg, String cls) {
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(pkg, cls));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void handlePermissionButtonClick() {
        try {
            ArrayList<String> permissions = new ArrayList<>();
            addPermissionIfDenied(permissions, Manifest.permission.RECEIVE_SMS);
            addPermissionIfDenied(permissions, Manifest.permission.READ_SMS);
            addPermissionIfDenied(permissions, Manifest.permission.SEND_SMS);
            addPermissionIfDenied(permissions, Manifest.permission.READ_PHONE_STATE);
            if (Build.VERSION.SDK_INT >= 26) {
                addPermissionIfDenied(permissions, "android.permission.READ_PHONE_NUMBERS");
            }
            if (Build.VERSION.SDK_INT >= 33) {
                addPermissionIfDenied(permissions, "android.permission.POST_NOTIFICATIONS");
            }

            if (!permissions.isEmpty()) {
                ActivityCompat.requestPermissions(this,
                        permissions.toArray(new String[0]),
                        CommonUtil.SMS_PHONE_PERMISSION_REQUEST_CODE);

                // OPPO 等系统可能直接限制短信权限，不弹普通授权框。
                // 缩短等待时间：如果短信权限仍未开启，尽快进入本应用权限页。
                new Handler().postDelayed(() -> {
                    if (!hasSmsPermission()) {
                        KeepAliveUtils.openAppPermissionSetting(this);
                    }
                }, 180);
            } else {
                KeepAliveUtils.openAppPermissionSetting(this);
            }
        } catch (Throwable e) {
            KeepAliveUtils.openAppPermissionSetting(this);
        }
    }

    private void addPermissionIfDenied(ArrayList<String> permissions, String permission) {
        try {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED
                    && !permissions.contains(permission)) {
                permissions.add(permission);
            }
        } catch (Throwable ignored) {
        }
    }

    private String getBrandGuideButtonText() {
        String type = getBrandGuideType();
        if ("xiaomi".equals(type)) return "小米教程";
        if ("oppo".equals(type)) return "OPPO教程";
        if ("vivo".equals(type)) return "vivo教程";
        if ("huawei".equals(type)) return "华为教程";
        return "设置教程";
    }

    private String getBrandGuideType() {
        String text = ((Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " "
                + (Build.BRAND == null ? "" : Build.BRAND) + " "
                + (Build.MODEL == null ? "" : Build.MODEL)).toLowerCase();
        if (text.contains("xiaomi") || text.contains("redmi") || text.contains("poco")) return "xiaomi";
        if (text.contains("oppo") || text.contains("oplus") || text.contains("oneplus") || text.contains("realme")) return "oppo";
        if (text.contains("vivo") || text.contains("iqoo")) return "vivo";
        if (text.contains("huawei") || text.contains("honor")) return "huawei";
        return "common";
    }

    private void showBrandGuideDialog() {
        String type = getBrandGuideType();
        GuideContent guide = loadBrandGuideFromAssets(type);
        if (guide == null || guide.content == null || guide.content.trim().length() == 0) {
            guide = new GuideContent(getBrandGuideButtonText(), "教程待填写。");
        }
        showGuideDialog(guide.title, guide.content);
    }

    private GuideContent loadBrandGuideFromAssets(String type) {
        String title = getBrandGuideButtonText();

        // v39：优先读取 TXT 教程文件。TXT 可以直接换行，后期用 MT 管理器修改最简单。
        // 对应文件：assets/tutorial_oppo.txt、tutorial_vivo.txt、tutorial_huawei.txt、tutorial_xiaomi.txt、tutorial_common.txt
        try {
            String txtContent = readAssetText("tutorial_" + type + ".txt");
            if (txtContent != null && txtContent.trim().length() > 0) {
                return new GuideContent(title, txtContent.trim());
            }
        } catch (Throwable ignored) {
        }

        try {
            String fallbackTxt = readAssetText("tutorial_common.txt");
            if (fallbackTxt != null && fallbackTxt.trim().length() > 0 && "common".equals(type)) {
                return new GuideContent(title, fallbackTxt.trim());
            }
        } catch (Throwable ignored) {
        }

        // 兼容旧版 JSON 配置。注意：JSON 的 content 不能直接按回车换行，必须写 \n，否则 JSON 会解析失败。
        try {
            String jsonText = readAssetText("brand_tutorials.json");
            if (jsonText == null || jsonText.trim().length() == 0) return null;
            JSONObject root = new JSONObject(jsonText);
            JSONObject item = root.optJSONObject(type);
            if (item == null) {
                item = root.optJSONObject("common");
            }
            if (item == null) return null;
            title = item.optString("title", title);
            String content = item.optString("content", "");
            return new GuideContent(title, content);
        } catch (Throwable e) {
            Log.e(TAG, "loadBrandGuideFromAssets:", e);
            return new GuideContent(title, "教程待填写。");
        }
    }

    private String readAssetText(String fileName) throws Exception {
        InputStream in = null;
        ByteArrayOutputStream out = null;
        try {
            in = getAssets().open(fileName);
            out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
            return out.toString("UTF-8");
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
            try { if (out != null) out.close(); } catch (Throwable ignored) {}
        }
    }

    private static class GuideContent {
        final String title;
        final String content;

        GuideContent(String title, String content) {
            this.title = title == null || title.trim().length() == 0 ? "设置教程" : title;
            this.content = content == null ? "" : content;
        }
    }

    private void showGuideDialog(String title, String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("知道了", null)
                .create();
        dialog.setOnShowListener(d -> {
            try {
                TextView msg = dialog.findViewById(android.R.id.message);
                if (msg != null) {
                    msg.setTextSize(17);
                    msg.setLineSpacing(dp(3), 1.08f);
                    msg.setTextColor(Color.parseColor("#222222"));
                }
                TextView titleView = dialog.findViewById(getResources().getIdentifier("alertTitle", "id", "android"));
                if (titleView != null) {
                    titleView.setTextSize(19);
                    titleView.setTypeface(Typeface.DEFAULT_BOLD);
                }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextSize(17);
            } catch (Throwable ignored) {
            }
        });
        dialog.show();
    }


    private void showSmsPermissionStepGuide() {
        String type = getBrandGuideType();
        if ("oppo".equals(type)) {
            showStepGuide("OPPO短信权限教程", getOppoSmsPermissionSteps(), true);
        } else if ("xiaomi".equals(type)) {
            showStepGuide("小米短信权限教程", getXiaomiSmsPermissionSteps(), true);
        } else if ("vivo".equals(type)) {
            showStepGuide("vivo短信权限教程", getVivoSmsPermissionSteps(), true);
        } else if ("huawei".equals(type)) {
            showStepGuide("华为短信权限教程", getHuaweiSmsPermissionSteps(), true);
        } else {
            showStepGuide("短信权限教程", getCommonSmsPermissionSteps(), true);
        }
    }

    private void showStepGuide(String title, String[] steps, boolean showPermissionButton) {
        final int[] index = new int[]{0};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(buildStepMessage(steps, index[0]))
                .setNegativeButton("上一步", null)
                .setPositiveButton("下一步", null)
                .setNeutralButton(showPermissionButton ? "去权限页" : "知道了", null)
                .create();

        dialog.setOnShowListener(d -> {
            try {
                TextView msg = dialog.findViewById(android.R.id.message);
                if (msg != null) {
                    msg.setTextSize(18);
                    msg.setLineSpacing(dp(4), 1.10f);
                    msg.setTextColor(Color.parseColor("#111111"));
                    msg.setGravity(Gravity.LEFT);
                }
                TextView titleView = dialog.findViewById(getResources().getIdentifier("alertTitle", "id", "android"));
                if (titleView != null) {
                    titleView.setTextSize(20);
                    titleView.setTypeface(Typeface.DEFAULT_BOLD);
                }
                Button prev = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
                Button next = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                Button go = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
                if (prev != null) prev.setTextSize(16);
                if (next != null) next.setTextSize(16);
                if (go != null) go.setTextSize(16);

                Runnable refresh = () -> {
                    TextView m = dialog.findViewById(android.R.id.message);
                    if (m != null) m.setText(buildStepMessage(steps, index[0]));
                    if (prev != null) prev.setEnabled(index[0] > 0);
                    if (next != null) next.setText(index[0] >= steps.length - 1 ? "完成" : "下一步");
                };

                if (prev != null) {
                    prev.setOnClickListener(v -> {
                        if (index[0] > 0) {
                            index[0]--;
                            refresh.run();
                        }
                    });
                }
                if (next != null) {
                    next.setOnClickListener(v -> {
                        if (index[0] < steps.length - 1) {
                            index[0]++;
                            refresh.run();
                        } else {
                            dialog.dismiss();
                        }
                    });
                }
                if (go != null) {
                    go.setOnClickListener(v -> {
                        dialog.dismiss();
                        KeepAliveUtils.openAppPermissionSetting(this);
                    });
                }
                refresh.run();
            } catch (Throwable ignored) {
            }
        });
        dialog.show();
    }

    private String buildStepMessage(String[] steps, int index) {
        return "第 " + (index + 1) + " 步 / 共 " + steps.length + " 步\n\n" + steps[index];
    }

    private String[] getOppoSmsPermissionSteps() {
        return new String[]{
                "点击下面的“去权限页”，\n进入本应用权限页面。",
                "找到“不允许”下面的“短信”。\n\n点进去后选择：允许。",
                "如果短信权限无法开启：\n\n点击右上角三个点，\n选择“解除所有授权限制”。",
                "返回权限列表，\n再次点击“短信”，\n选择“允许”。",
                "返回本软件查看状态：\n短信权限：已开启。\n\n如果还显示未开启，\n再点一次“权限”检查。"
        };
    }

    private String[] getXiaomiSmsPermissionSteps() {
        return new String[]{
                "点击下面的“去权限页”，\n进入本应用权限页面。",
                "找到“短信”，\n设置为：允许。",
                "再进入：其他权限 或 更多权限。",
                "拉到比较靠下面，\n找到“通知类短信”，\n设置为：始终允许。",
                "返回本软件查看状态：\n短信权限：已开启。"
        };
    }

    private String[] getVivoSmsPermissionSteps() {
        return new String[]{
                "点击下面的“去权限页”，\n进入本应用权限页面。",
                "找到“短信”权限。",
                "把“短信”设置为：允许。",
                "返回本软件查看状态：\n短信权限：已开启。"
        };
    }

    private String[] getHuaweiSmsPermissionSteps() {
        return new String[]{
                "点击下面的“去权限页”，\n进入本应用权限页面。",
                "点击“权限”或“权限管理”。",
                "找到“信息”或“短信”。",
                "设置为：允许。",
                "返回本软件查看状态：\n短信权限：已开启。"
        };
    }

    private String[] getCommonSmsPermissionSteps() {
        return new String[]{
                "点击下面的“去权限页”，\n进入本应用权限页面。",
                "找到“权限”或“权限管理”。",
                "找到“短信”。",
                "设置为：允许。",
                "返回本软件查看状态：\n短信权限：已开启。"
        };
    }

    private String getXiaomiGuideText() {
        return "1. 短信权限\n"
                + "打开本应用权限：短信\n\n"
                + "再进入：其他权限 或 更多权限\n"
                + "拉到比较靠下面\n"
                + "找到“通知类短信”\n"
                + "设置为：始终允许\n\n"
                + "2. 电池设置\n"
                + "设置 → 电池 或 省电与电池\n"
                + "进入“更多电池功能”\n\n"
                + "把下面两项设为“从不”：\n"
                + "锁屏断开数据\n"
                + "锁屏清理内存\n\n"
                + "正常均衡模式即可，\n"
                + "不要开启省电模式。\n\n"
                + "3. 自启动\n"
                + "设置搜索“自启动”\n"
                + "找到本应用，允许自启动\n\n"
                + "也可以：\n"
                + "设置 → 应用设置 → 应用管理\n"
                + "右上角 → 自启动\n\n"
                + "4. 短信通知关闭\n"
                + "长按短信软件\n"
                + "进入应用信息\n"
                + "点击“通知”\n"
                + "关闭所有开关";
    }

    private String getOppoGuideText() {
        return "1. 短信权限\n"
                + "进入本应用详情\n"
                + "打开“短信”权限\n\n"
                + "如果短信权限无法开启：\n"
                + "点右上角三个点\n"
                + "选择“解除限制”\n\n"
                + "2. 电池设置\n"
                + "点击“电池”\n"
                + "进入“省电设置”\n"
                + "关闭“睡眠待机优化”\n\n"
                + "再进入：应用耗电管理\n"
                + "找到本应用\n"
                + "选择“完全允许后台行为”\n\n"
                + "3. 自启动\n"
                + "设置搜索“自启动”\n"
                + "找到本应用，开启即可\n\n"
                + "4. 验证码保护\n"
                + "打开短信\n"
                + "点右上角三个点\n"
                + "设置 → 智能信息服务\n"
                + "关闭“验证码安全保护”\n\n"
                + "5. 关闭短信通知\n"
                + "长按“信息”\n"
                + "进入应用详情\n"
                + "点击“通知管理”\n"
                + "关闭开关";
    }

    private String getVivoGuideText() {
        return "1. 短信权限\n"
                + "打开本应用权限\n"
                + "确认“短信”已开启\n\n"
                + "2. 电池设置\n"
                + "打开“电池”\n"
                + "进入“后台耗电管理”\n"
                + "找到本应用\n"
                + "设置为“允许后台耗电”\n\n"
                + "再回到电池首页\n"
                + "点击“更多设置”\n"
                + "关闭“睡眠模式”\n\n"
                + "如果有“休眠断开网络”\n"
                + "也关闭\n\n"
                + "3. 自启动\n"
                + "设置搜索“自启动”\n"
                + "找到本应用\n"
                + "开启自启动\n\n"
                + "4. 验证码保护\n"
                + "打开短信\n"
                + "点右上角两个点\n"
                + "设置 → 隐私保护\n"
                + "关闭“验证码保护”\n\n"
                + "5. 关闭短信通知\n"
                + "长按“信息”\n"
                + "应用信息 → 通知\n"
                + "把蓝色对勾框全部关闭\n\n"
                + "再到设置搜索“原子通知”\n"
                + "进入后把“信息”关闭";
    }

    private String getHuaweiGuideText() {
        return "1. 短信权限\n"
                + "打开本应用权限\n"
                + "确认“短信”已开启\n\n"
                + "2. 电池设置\n"
                + "设置 → 电池\n"
                + "确认没有开启省电模式\n\n"
                + "3. 应用启动管理\n"
                + "设置 → 应用和服务\n"
                + "进入“应用启动管理”\n"
                + "找到本应用\n"
                + "改为手动管理\n"
                + "允许自启动、关联启动、后台活动\n\n"
                + "4. 验证码保护\n"
                + "打开短信设置\n"
                + "如有验证码保护\n"
                + "请关闭\n\n"
                + "5. 关闭短信通知\n"
                + "长按“信息”\n"
                + "进入应用信息\n"
                + "点击通知\n"
                + "关闭相关开关";
    }

    private String getCommonGuideText() {
        return "1. 短信权限\n"
                + "打开本应用权限\n"
                + "确认“短信”已开启\n\n"
                + "2. 电池设置\n"
                + "进入手机电池设置\n"
                + "允许本应用后台运行\n\n"
                + "3. 自启动\n"
                + "设置搜索“自启动”\n"
                + "找到本应用并开启\n\n"
                + "4. 短信通知\n"
                + "按需要关闭短信软件通知";
    }

    private String getSimNumberDisplay() {
        try {
            if (MyApplication.SimInfoList == null || MyApplication.SimInfoList.isEmpty()) {
                MyApplication.SimInfoList = PhoneUtils.getSimMultiInfo();
            }
            if (MyApplication.SimInfoList == null || MyApplication.SimInfoList.isEmpty()) {
                return "手机号：未读取";
            }
            StringBuilder sb = new StringBuilder("手机号：");
            boolean hasAny = false;
            for (PhoneUtils.SimInfo simInfo : MyApplication.SimInfoList) {
                if (simInfo == null) continue;
                int slot = simInfo.mSimSlotIndex >= 0 ? simInfo.mSimSlotIndex + 1 : 1;
                String number = simInfo.mNumber == null ? "" : String.valueOf(simInfo.mNumber).trim();
                if (number.length() == 0 || "null".equalsIgnoreCase(number)) number = "未读取";
                if (hasAny) sb.append("\n　　　");
                sb.append("SIM卡").append(slot).append("：").append(number);
                hasAny = true;
            }
            if (!hasAny) return "手机号：未读取";
            return sb.toString();
        } catch (Throwable e) {
            return "手机号：未读取";
        }
    }

    private String getCommonModelName(String model) {
        if (model == null || model.trim().length() == 0) return "未知";
        String m = model.trim();
        String lower = m.toLowerCase();
        // 常见工程型号转日常名称，后续测试到更多型号可以继续追加。
        if (lower.contains("xt2201-2") || lower.contains("xt2201")) {
            return "摩托罗拉 X30（" + m + "）";
        }
        return m;
    }

    private Button buildFloatingButton(String text, String color) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(text.length() >= 3 ? 13 : 14);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(Color.WHITE);
        button.setPadding(0, 0, 0, 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(Color.parseColor(color));
        bg.setStroke(dp(1), Color.parseColor("#555555"));
        bg.setCornerRadius(dp(28));
        button.setBackground(bg);
        return button;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");

        //是否关闭页面提示
        TextView help_tip = findViewById(R.id.help_tip);
        help_tip.setVisibility(MyApplication.showHelpTip ? View.VISIBLE : View.GONE);

        // 先拿到数据并放在适配器上
        initTLogs(); //初始化数据
        showList(logVos);

        //切换日志类别
        int typeCheckId = getTypeCheckId(currentType);
        final RadioGroup radioGroupTypeCheck = findViewById(R.id.radioGroupTypeCheck);
        radioGroupTypeCheck.check(typeCheckId);
        radioGroupTypeCheck.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = findViewById(checkedId);
            currentType = (String) rb.getTag();
            initTLogs();
            showList(logVos);
        });

        // 为ListView注册一个监听器，当用户点击了ListView中的任何一个子项时，就会回调onItemClick()方法
        // 在这个方法中可以通过position参数判断出用户点击的是那一个子项
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position <= 0) return;

            LogVo logVo = logVos.get(position - 1);
            logDetail(logVo);
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position <= 0) return false;

            //定义AlertDialog.Builder对象，当长按列表项的时候弹出确认删除对话框
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle(R.string.delete_log_title);
            builder.setMessage(R.string.delete_log_tips);

            //添加AlertDialog.Builder对象的setPositiveButton()方法
            builder.setPositiveButton(R.string.confirm, (dialog, which) -> {
                Long id1 = logVos.get(position - 1).getId();
                Log.d(TAG, "id = " + id1);
                LogUtil.delLog(id1, null);
                initTLogs(); //初始化数据
                showList(logVos);
                Toast.makeText(getBaseContext(), R.string.delete_log_toast, Toast.LENGTH_SHORT).show();
            });

            //添加AlertDialog.Builder对象的setNegativeButton()方法
            builder.setNegativeButton(R.string.cancel, (dialog, which) -> {
            });

            builder.create().show();
            return true;
        });
    }

    private int getTypeCheckId(String currentType) {
        switch (currentType) {
            case "call":
                return R.id.btnTypeCall;
            case "app":
                return R.id.btnTypeApp;
            default:
                return R.id.btnTypeSms;
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    @Override
    protected void onResume() {
        super.onResume();

        
        if (deviceInfoLabel != null) {
            deviceInfoLabel.setText(getFriendlyDeviceName());
            applyStatusTextStyle();
        }
        checkXiaomiSmsPermissionOnHome();
//第一次打开，未授权无法获取SIM信息，尝试在此重新获取
        if (MyApplication.SimInfoList.isEmpty()) {
            MyApplication.SimInfoList = PhoneUtils.getSimMultiInfo();
        }
        Log.d(TAG, "SimInfoList = " + MyApplication.SimInfoList.size());
        if (deviceInfoLabel != null) {
            deviceInfoLabel.setText(getFriendlyDeviceName());
        }
        if (SettingUtil.getExcludeFromRecents()) {
            RecentsHideUtil.applyForActivity(this, true);
        }

        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            boolean xiaomiNeedOpenBattery = getSharedPreferences("quick_settings", MODE_PRIVATE)
                    .getBoolean("xiaomi_open_battery_home_after_return", false);
            if (xiaomiNeedOpenBattery && isXiaomiLike()) {
                getSharedPreferences("quick_settings", MODE_PRIVATE)
                        .edit()
                        .putBoolean("xiaomi_open_battery_home_after_return", false)
                        .putBoolean("open_battery_after_optimization", false)
                        .apply();
                new Handler().postDelayed(() -> {
                    if (!isFinishing()) {
                        KeepAliveUtils.openAppBatterySetting(this);
                    }
                }, 500);
                return;
            }

            boolean needOpenBattery = getSharedPreferences("quick_settings", MODE_PRIVATE)
                    .getBoolean("open_battery_after_optimization", false);
            if (needOpenBattery && KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                getSharedPreferences("quick_settings", MODE_PRIVATE)
                        .edit()
                        .putBoolean("open_battery_after_optimization", false)
                        .apply();
                KeepAliveUtils.openAppBatterySetting(this);
                return;
            }
        }

        //开启读取通知栏权限
        if (SettingUtil.getSwitchEnableAppNotify() && !CommonUtil.isNotificationListenerServiceEnabled(this)) {
            CommonUtil.toggleNotificationListenerService(this);
            SettingUtil.switchEnableAppNotify(false);
            Toast.makeText(this, R.string.tips_notification_listener, Toast.LENGTH_LONG).show();
            return;
        }

        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onResume:", e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            smsPermissionReminderHandler.removeCallbacksAndMessages(null);
        } catch (Throwable ignored) {
        }
        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onDestroy:", e);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onPause:", e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CommonUtil.NOTIFICATION_REQUEST_CODE) {
            if (CommonUtil.isNotificationListenerServiceEnabled(this)) {
                Toast.makeText(this, R.string.notification_listener_service_enabled, Toast.LENGTH_SHORT).show();
                CommonUtil.toggleNotificationListenerService(this);
            } else {
                Toast.makeText(this, R.string.notification_listener_service_disabled, Toast.LENGTH_SHORT).show();
            }
        }
    }

    // 权限判断相关

    // 初始化数据
    private void initTLogs() {
        logVos = LogUtil.getLog(null, null, currentType);
    }

    private void showList(List<LogVo> logVosN) {
        Log.d(TAG, "showList: " + logVosN);
        if (adapter == null) {
            // 将适配器上的数据传递给listView
            listView = findViewById(R.id.list_view_log);
            listView.setInterface(this);
            adapter = new LogAdapter(MainActivity.this, R.layout.item_log, logVosN);
            listView.setAdapter(adapter);
        } else {
            adapter.onDateChange(logVosN);
        }
    }

    @Override
    public void onRefresh() {
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            // TODO Auto-generated method stub
            //获取最新数据
            initTLogs();
            //通知界面显示
            showList(logVos);
            //通知listview 刷新数据完毕；
            listView.refreshComplete();
        }, 2000);
    }

    public void logDetail(LogVo logVo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.details);
        String simInfo = logVo.getSimInfo();
        if (simInfo != null) {
            builder.setMessage(logVo.getFrom() + "\n\n" + logVo.getContent() + "\n\n" + logVo.getSimInfo() + "\n\n" + logVo.getRule() + "\n\n" + TimeUtil.utc2Local(logVo.getTime()) + "\n\nResponse：" + logVo.getForwardResponse());
        } else {
            builder.setMessage(logVo.getFrom() + "\n\n" + logVo.getContent() + "\n\n" + logVo.getRule() + "\n\n" + TimeUtil.utc2Local(logVo.getTime()) + "\n\nResponse：" + logVo.getForwardResponse());
        }
        //删除
        builder.setNegativeButton(R.string.del, (dialog, which) -> {
            Long id = logVo.getId();
            Log.d(TAG, "id = " + id);
            LogUtil.delLog(id, null);
            initTLogs(); //初始化数据
            showList(logVos);
            Toast.makeText(MainActivity.this, R.string.delete_log_toast, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        builder.show();
    }

    public void toAppList() {
        Intent intent = new Intent(this, AppListActivity.class);
        startActivity(intent);
    }

    public void toClone() {
        Intent intent = new Intent(this, CloneActivity.class);
        startActivity(intent);
    }

    public void toSetting() {
        Intent intent = new Intent(this, SettingActivity.class);
        startActivity(intent);
    }

    public void toAbout() {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }

    public void toHelp() {
        Toast.makeText(this, "当前版本已精简帮助入口", Toast.LENGTH_SHORT).show();
    }

    public void toRuleSetting(View view) {
        Intent intent = new Intent(this, RuleActivity.class);
        startActivity(intent);
    }

    public void toSendSetting(View view) {
        Intent intent = new Intent(this, SenderActivity.class);
        startActivity(intent);
    }

    public void toRuleSettingDoubleClick(View view) {
        long now = System.currentTimeMillis();
        if (now - lastRuleClickTime < 1200) {
            lastRuleClickTime = 0L;
            toRuleSetting(view);
        } else {
            lastRuleClickTime = now;
        }
    }

    public void toSendSettingDoubleClick(View view) {
        long now = System.currentTimeMillis();
        if (now - lastSendClickTime < 1200) {
            lastSendClickTime = 0L;
            toSendSetting(view);
        } else {
            lastSendClickTime = now;
        }
    }

    public void cleanLog(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.clear_logs_tips)
                .setPositiveButton(R.string.confirm, (dialog, which) -> {
                    // TODO Auto-generated method stub
                    LogUtil.delLog(null, null);
                    initTLogs();
                    adapter.add(logVos);
                });
        builder.show();
    }

    //按返回键不退出回到桌面
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }

    //启用menu：右上角直接显示设置入口，不再弹出多个菜单
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //menu点击事件
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.to_app_list:
                toAppList();
                return true;
            case R.id.to_clone:
                toClone();
                return true;
            case R.id.to_setting:
                toSetting();
                return true;
            case R.id.to_about:
                toAbout();
                return true;
            case R.id.to_help:
                toHelp();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //设置menu图标显示
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        if (featureId == Window.FEATURE_ACTION_BAR && menu != null) {
            if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
                try {
                    Method m = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);
                    m.setAccessible(true);
                    m.invoke(menu, true);
                } catch (NoSuchMethodException e) {
                    Log.e(TAG, "onMenuOpened", e);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return super.onMenuOpened(featureId, menu);
    }

}
