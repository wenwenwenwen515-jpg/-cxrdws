package com.idormy.sms.forwarder.model.vo;

import com.idormy.sms.forwarder.R;

import java.io.Serializable;

import lombok.Data;

@Data
public class WebNotifySettingVo implements Serializable {
    private String webServer;
    private String secret;
    private String method;
    private String webParams;

    public WebNotifySettingVo() {
    }

    public WebNotifySettingVo(String webServer, String secret, String method, String webParams) {
        this.webServer = webServer;
        this.secret = secret;
        this.method = method;
        this.webParams = webParams;
    }

    public int getWebNotifyMethodCheckId() {
        if (method == null || method.equals("POST")) {
            return R.id.radioWebNotifyMethodPost;
        } else {
            return R.id.radioWebNotifyMethodGet;
        }
    }


    // 显式 getter/setter：避免部分构建环境 Lombok 生成失败导致编译错误。
    public String getWebServer() {
        return webServer;
    }

    public void setWebServer(String webServer) {
        this.webServer = webServer;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getWebParams() {
        return webParams;
    }

    public void setWebParams(String webParams) {
        this.webParams = webParams;
    }

}
