package com.idormy.sms.forwarder.model;

import androidx.annotation.NonNull;

import lombok.Data;

@Data
public class LogModel {
    private String from;
    private String content;
    private Long ruleId;
    private Long time;
    private String simInfo;
    private String type;

    public LogModel(String type, String from, String content, String simInfo, Long ruleId) {
        this.from = from;
        this.content = content;
        this.simInfo = simInfo;
        this.ruleId = ruleId;
        this.type = type;
    }

    @NonNull
    @Override
    public String toString() {
        return "LogModel{" +
                "from='" + from + '\'' +
                ", content='" + content + '\'' +
                ", simInfo=" + simInfo +
                ", ruleId=" + ruleId +
                ", type=" + type +
                ", time=" + time +
                '}';
    }
    // 显式 getter/setter：避免部分构建环境 Lombok 生成失败导致编译错误。
    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getRuleId() {
        return ruleId;
    }

    public void setRuleId(Long ruleId) {
        this.ruleId = ruleId;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getSimInfo() {
        return simInfo;
    }

    public void setSimInfo(String simInfo) {
        this.simInfo = simInfo;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
