package com.idormy.sms.forwarder.model.vo;

import lombok.Data;

@Data
public class RuleVo {
    private String matchStr;
    private String senderStr;
    // 显式 getter/setter：避免部分构建环境 Lombok 生成失败导致编译错误。
    public String getMatchStr() {
        return matchStr;
    }

    public void setMatchStr(String matchStr) {
        this.matchStr = matchStr;
    }

    public String getSenderStr() {
        return senderStr;
    }

    public void setSenderStr(String senderStr) {
        this.senderStr = senderStr;
    }

}
