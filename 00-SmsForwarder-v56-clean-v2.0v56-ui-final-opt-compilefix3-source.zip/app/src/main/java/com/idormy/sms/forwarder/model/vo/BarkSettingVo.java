package com.idormy.sms.forwarder.model.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class BarkSettingVo implements Serializable {
    private String server;
    private String icon;

    public BarkSettingVo() {
    }

    public BarkSettingVo(String server, String icon) {
        this.server = server;
        this.icon = icon;
    }

    // 显式 getter/setter：避免部分构建环境 Lombok 生成失败导致编译错误。
    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

}
