package com.idormy.sms.forwarder.model;

import lombok.Data;

@Data
public class PhoneBookEntity {
    private String name;
    private String phoneNumber;

    public PhoneBookEntity(String name, String phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }
    // 显式 getter/setter：避免部分构建环境 Lombok 生成失败导致编译错误。
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
