package com.idormy.sms.forwarder.model.vo;

import com.idormy.sms.forwarder.R;

import lombok.Data;

@Data
public class LogVo {
    private Long id;
    private String from;
    private String content;
    private String simInfo;
    private String rule;
    private int senderImageId;
    private String time;
    private int forwardStatus;
    private String forwardResponse;

    public LogVo() {
    }

    public LogVo(Long id, String from, String content, String simInfo, String time, String rule, int senderImageId, int forwardStatus, String forwardResponse) {
        this.id = id;
        this.from = from;
        this.content = content;
        this.simInfo = simInfo;
        this.time = time;
        this.rule = rule;
        this.senderImageId = senderImageId;
        this.forwardStatus = forwardStatus;
        this.forwardResponse = forwardResponse;
    }

    public int getSimImageId() {
        if (this.simInfo != null && !this.simInfo.isEmpty()) {
            if (this.simInfo.replace("-", "").startsWith("SIM2")) {
                return R.drawable.sim2; //mipmap
            } else if (this.simInfo.replace("-", "").startsWith("SIM1")) {
                return R.drawable.sim1;
            }
        }

        return R.drawable.ic_app;
    }

    public int getStatusImageId() {
        if (this.forwardStatus == 1) {
            return R.drawable.ic_round_check;
        }

        return R.drawable.ic_round_cancel;
    }
    // 显式 getter/setter：避免部分构建环境 Lombok 生成失败导致编译错误。
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSimInfo() {
        return simInfo;
    }

    public void setSimInfo(String simInfo) {
        this.simInfo = simInfo;
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule;
    }

    public int getSenderImageId() {
        return senderImageId;
    }

    public void setSenderImageId(int senderImageId) {
        this.senderImageId = senderImageId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getForwardStatus() {
        return forwardStatus;
    }

    public void setForwardStatus(int forwardStatus) {
        this.forwardStatus = forwardStatus;
    }

    public String getForwardResponse() {
        return forwardResponse;
    }

    public void setForwardResponse(String forwardResponse) {
        this.forwardResponse = forwardResponse;
    }

}
