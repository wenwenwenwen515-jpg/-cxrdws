package com.idormy.sms.forwarder.model;

import android.content.Intent;
import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;

import lombok.Data;

@Data
public class AppInfo {
    public String pkgName;
    public String appName;
    public Drawable appIcon;
    public Intent appIntent;
    public String verName;
    public int verCode;

    public AppInfo() {
    }

    public AppInfo(String appName) {
        this.appName = appName;
    }

    public AppInfo(String appName, String pkgName) {
        this.appName = appName;
        this.pkgName = pkgName;
    }

    public AppInfo(String appName, String pkgName, Drawable appIcon, String verName, int verCode) {
        this.appName = appName;
        this.pkgName = pkgName;
        this.appIcon = appIcon;
        this.verName = verName;
        this.verCode = verCode;
    }

    @NonNull
    @Override
    public String toString() {
        return "AppInfo{" +
                "appName='" + appName + '\'' +
                ", pkgName='" + pkgName + '\'' +
                ", appIcon=" + appIcon +
                ", verName=" + verName +
                ", verCode=" + verCode +
                '}';
    }
    // 显式 getter/setter：避免部分构建环境 Lombok 生成失败导致编译错误。
    public String getPkgName() {
        return pkgName;
    }

    public void setPkgName(String pkgName) {
        this.pkgName = pkgName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Drawable getAppIcon() {
        return appIcon;
    }

    public void setAppIcon(Drawable appIcon) {
        this.appIcon = appIcon;
    }

    public Intent getAppIntent() {
        return appIntent;
    }

    public void setAppIntent(Intent appIntent) {
        this.appIntent = appIntent;
    }

    public String getVerName() {
        return verName;
    }

    public void setVerName(String verName) {
        this.verName = verName;
    }

    public int getVerCode() {
        return verCode;
    }

    public void setVerCode(int verCode) {
        this.verCode = verCode;
    }

}
