package com.idormy.sms.forwarder;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Telephony;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SmsProtectActivity extends Activity {

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showProtectedPage();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showProtectedPage();
    }

    private void showProtectedPage() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(26), dp(26), dp(26), dp(26));
        root.setBackgroundColor(Color.parseColor("#F7F9FC"));

        TextView shield = new TextView(this);
        shield.setText("🛡️");
        shield.setTextSize(46);
        shield.setGravity(Gravity.CENTER);
        root.addView(shield, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("验证码保护中");
        title.setTextColor(Color.parseColor("#111111"));
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.setMargins(0, dp(10), 0, dp(8));
        root.addView(title, titleLp);

        String defaultPkg = null;
        try {
            defaultPkg = Telephony.Sms.getDefaultSmsPackage(this);
        } catch (Throwable ignored) {
        }
        boolean isDefault = getPackageName().equals(defaultPkg);

        TextView desc = new TextView(this);
        desc.setText(isDefault
                ? "当前已接管默认短信入口。\n短信内容不会在这里显示。"
                : "当前还不是默认短信应用。\n请返回软件内点击【短信验证码保护】设置默认短信。");
        desc.setTextColor(Color.parseColor("#444444"));
        desc.setTextSize(16);
        desc.setGravity(Gravity.CENTER);
        desc.setLineSpacing(dp(2), 1.05f);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        descLp.setMargins(0, dp(6), 0, dp(22));
        root.addView(desc, descLp);

        Button close = new Button(this);
        close.setText("知道了");
        close.setTextSize(16);
        close.setAllCaps(false);
        close.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(dp(150), dp(46));
        btnLp.setMargins(0, dp(4), 0, 0);
        root.addView(close, btnLp);

        setContentView(root);
    }
}
