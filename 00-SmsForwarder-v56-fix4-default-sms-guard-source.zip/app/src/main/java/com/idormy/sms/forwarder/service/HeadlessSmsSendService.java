package com.idormy.sms.forwarder.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class HeadlessSmsSendService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("HeadlessSmsSendService", "respond via message blocked by protect mode");
        return null;
    }
}
