package com.idormy.sms.forwarder.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class WapPushReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("WapPushReceiver", "MMS/WAP push received in protect mode: " + (intent == null ? "" : intent.getAction()));
    }
}
