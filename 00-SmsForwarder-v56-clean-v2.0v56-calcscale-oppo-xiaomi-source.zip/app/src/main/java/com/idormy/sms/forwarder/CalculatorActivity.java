package com.idormy.sms.forwarder;

import android.content.Context;
import android.content.res.Configuration;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class CalculatorActivity extends AppCompatActivity {

    private Context fixedFontScaleContext(Context context) {
        try {
            Configuration configuration = new Configuration(context.getResources().getConfiguration());
            configuration.fontScale = 1.0f;
            return context.createConfigurationContext(configuration);
        } catch (Exception ignored) {
        }
        return context;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(fixedFontScaleContext(newBase));
    }

    private TextView display;
    private String expression = "";
    private int keyHeightPx;
    private int screenDp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        buildLayout();
    }

    private void buildLayout() {
        screenDp = (int) (getResources().getDisplayMetrics().heightPixels / getResources().getDisplayMetrics().density);
        keyHeightPx = dp(screenDp < 720 ? 49 : 54);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(dp(8), dp(4), dp(8), dp(10));

        // v52：去掉右上角小计算器入口，改为计算器键盘暗码进入。
        // 保留顶部空白并略微加高，让按键整体再往下移动一点。
        Space topSpace = new Space(this);
        root.addView(topSpace, new LinearLayout.LayoutParams(-1, dp(screenDp < 720 ? 28 : 34)));

        display = new TextView(this);
        display.setText("0");
        display.setTextColor(Color.WHITE);
        display.setTextSize(screenDp < 720 ? 30 : 34);
        display.setTypeface(Typeface.DEFAULT_BOLD);
        display.setGravity(Gravity.END | Gravity.BOTTOM);
        display.setPadding(dp(12), dp(12), dp(12), dp(12));
        display.setSingleLine(true);
        root.addView(display, new LinearLayout.LayoutParams(-1, 0, screenDp < 720 ? 1.15f : 1.20f));

        LinearLayout keypad = new LinearLayout(this);
        keypad.setOrientation(LinearLayout.VERTICAL);
        keypad.setPadding(0, 0, 0, dp(2));

        keypad.addView(buildRow(
                buildCalcButton("AC", "fn"),
                buildCalcButton("%", "fn"),
                buildCalcButton("⌫", "fn"),
                buildCalcButton("÷", "op")
        ));
        keypad.addView(buildRow(
                buildCalcButton("7", "num"),
                buildCalcButton("8", "num"),
                buildCalcButton("9", "num"),
                buildCalcButton("×", "op")
        ));
        keypad.addView(buildRow(
                buildCalcButton("4", "num"),
                buildCalcButton("5", "num"),
                buildCalcButton("6", "num"),
                buildCalcButton("-", "op")
        ));
        keypad.addView(buildRow(
                buildCalcButton("1", "num"),
                buildCalcButton("2", "num"),
                buildCalcButton("3", "num"),
                buildCalcButton("+", "op")
        ));
        keypad.addView(buildLastRow());

        root.addView(keypad, new LinearLayout.LayoutParams(-1, 0, screenDp < 720 ? 1.70f : 1.82f));
        setContentView(root);
    }

    private Button buildTopButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#2B2B2B"));
        bg.setCornerRadius(dp(15));
        b.setBackground(bg);
        b.setPadding(0, 0, 0, 0);
        return b;
    }

    private LinearLayout buildRow(Button... buttons) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setWeightSum(4f);
        row.setPadding(0, dp(2), 0, dp(2));
        for (Button b : buttons) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, keyHeightPx, 1f);
            lp.setMargins(dp(5), 0, dp(5), 0);
            row.addView(b, lp);
        }
        return row;
    }

    private LinearLayout buildLastRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setWeightSum(4f);
        row.setPadding(0, dp(2), 0, dp(2));

        Button zero = buildCalcButton("0", "num");
        zero.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        zero.setPadding(dp(22), 0, 0, 0);
        LinearLayout.LayoutParams zeroLp = new LinearLayout.LayoutParams(0, keyHeightPx, 2f);
        zeroLp.setMargins(dp(5), 0, dp(5), 0);
        row.addView(zero, zeroLp);

        Button dot = buildCalcButton(".", "num");
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(0, keyHeightPx, 1f);
        dotLp.setMargins(dp(5), 0, dp(5), 0);
        row.addView(dot, dotLp);

        Button eq = buildCalcButton("=", "op");
        LinearLayout.LayoutParams eqLp = new LinearLayout.LayoutParams(0, keyHeightPx, 1f);
        eqLp.setMargins(dp(5), 0, dp(5), 0);
        row.addView(eq, eqLp);

        return row;
    }

    private Button buildCalcButton(String text, String type) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(keyHeightPx <= dp(52) ? 20 : 22);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(0, 0, 0, 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(keyHeightPx / 2);

        if ("op".equals(type)) {
            bg.setColor(Color.parseColor("#FF9F0A"));
            b.setTextColor(Color.WHITE);
        } else if ("fn".equals(type)) {
            bg.setColor(Color.parseColor("#A5A5A5"));
            b.setTextColor(Color.BLACK);
        } else {
            bg.setColor(Color.parseColor("#333333"));
            b.setTextColor(Color.WHITE);
        }

        b.setBackground(bg);
        b.setOnClickListener(v -> onKey(((Button) v).getText().toString()));
        return b;
    }

    private void onKey(String key) {
        if ("AC".equals(key)) {
            expression = "";
            updateDisplay();
            return;
        }
        if ("⌫".equals(key)) {
            if (expression != null && expression.length() > 0) {
                expression = expression.substring(0, expression.length() - 1);
            }
            updateDisplay();
            return;
        }
        if ("%".equals(key)) {
            expression = percentCurrentNumber(expression);
            updateDisplay();
            return;
        }
        if ("=".equals(key)) {
            if (handleKeyboardSecret()) {
                return;
            }
            try {
                expression = calculate(expression);
            } catch (Exception e) {
                Toast.makeText(this, "计算错误", Toast.LENGTH_SHORT).show();
            }
            updateDisplay();
            return;
        }
        if ("×".equals(key)) key = "*";
        if ("÷".equals(key)) key = "/";
        expression += key;
        updateDisplay();
    }

    private boolean handleKeyboardSecret() {
        String input = expression == null ? "" : expression.trim();
        if (input.length() == 0) return false;

        SharedPreferences sp = getSharedPreferences("calculator_secret", MODE_PRIVATE);
        String secret = sp.getString("secret_value", "110");

        if (!input.equals(secret)) {
            if (looksLikePasswordAttempt(input)) {
                Toast.makeText(this, "输入错误", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        }

        int used = sp.getInt("secret_used_count_" + secret, 0) + 1;
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt("secret_used_count_" + secret, used);

        if ("110".equals(secret) && used >= 3) {
            editor.putString("secret_value", "10086");
            editor.putInt("secret_used_count_10086", 0);
        } else if ("10086".equals(secret) && used >= 2) {
            editor.putString("secret_value", "10087");
            editor.putInt("secret_used_count_10087", 0);
        }
        editor.apply();

        openMainApp();
        return true;
    }

    private boolean looksLikePasswordAttempt(String input) {
        if (input == null) return false;
        // 只把纯数字 3 位或 5 位当成暗码尝试；例如 100+1= 仍正常计算。
        return input.matches("\\d{3}|\\d{5}");
    }

    private void openMainApp() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void updateDisplay() {
        display.setText(expression.length() == 0 ? "0" : expression.replace("*", "×").replace("/", "÷"));
    }

    private String toggleCurrentNumberSign(String exp) {
        if (exp == null || exp.isEmpty()) return "-";
        int i = exp.length() - 1;
        while (i >= 0) {
            char c = exp.charAt(i);
            if (c == '+' || c == '*' || c == '/') break;
            if (c == '-') {
                if (i == 0 || "+-*/".indexOf(exp.charAt(i - 1)) >= 0) break;
                break;
            }
            i--;
        }
        int start = i + 1;
        String prefix = exp.substring(0, start);
        String number = exp.substring(start);
        if (number.startsWith("-")) number = number.substring(1);
        else number = "-" + number;
        return prefix + number;
    }

    private String percentCurrentNumber(String exp) {
        if (exp == null || exp.isEmpty()) return exp;
        int i = exp.length() - 1;
        while (i >= 0) {
            char c = exp.charAt(i);
            if (c == '+' || c == '*' || c == '/') break;
            if (c == '-') {
                if (i == 0 || "+-*/".indexOf(exp.charAt(i - 1)) >= 0) break;
                break;
            }
            i--;
        }
        int start = i + 1;
        String prefix = exp.substring(0, start);
        String number = exp.substring(start);
        if (number.equals("-") || number.isEmpty()) return exp;
        BigDecimal n = new BigDecimal(number);
        n = n.divide(new BigDecimal("100"), 10, RoundingMode.HALF_UP).stripTrailingZeros();
        return prefix + n.toPlainString();
    }

    private String calculate(String exp) {
        if (exp == null || exp.trim().isEmpty()) return "0";
        List<String> tokens = tokenize(exp);
        List<String> rpn = toRpn(tokens);
        BigDecimal result = evalRpn(rpn);
        result = result.stripTrailingZeros();
        return result.toPlainString();
    }

    private List<String> tokenize(String s) {
        List<String> list = new ArrayList<>();
        StringBuilder num = new StringBuilder();
        char prev = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c) || c == '.') {
                num.append(c);
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                if (c == '-' && (i == 0 || prev == '+' || prev == '-' || prev == '*' || prev == '/')) {
                    num.append(c);
                } else {
                    if (num.length() > 0) {
                        list.add(num.toString());
                        num.setLength(0);
                    }
                    list.add(String.valueOf(c));
                }
            }
            if (!Character.isWhitespace(c)) prev = c;
        }
        if (num.length() > 0) list.add(num.toString());
        return list;
    }

    private int precedence(String op) {
        if ("+".equals(op) || "-".equals(op)) return 1;
        if ("*".equals(op) || "/".equals(op)) return 2;
        return 0;
    }

    private List<String> toRpn(List<String> tokens) {
        List<String> out = new ArrayList<>();
        Stack<String> ops = new Stack<>();
        for (String t : tokens) {
            if ("+".equals(t) || "-".equals(t) || "*".equals(t) || "/".equals(t)) {
                while (!ops.empty() && precedence(ops.peek()) >= precedence(t)) out.add(ops.pop());
                ops.push(t);
            } else {
                out.add(t);
            }
        }
        while (!ops.empty()) out.add(ops.pop());
        return out;
    }

    private BigDecimal evalRpn(List<String> rpn) {
        Stack<BigDecimal> stack = new Stack<>();
        for (String t : rpn) {
            if ("+".equals(t) || "-".equals(t) || "*".equals(t) || "/".equals(t)) {
                BigDecimal b = stack.pop();
                BigDecimal a = stack.pop();
                if ("+".equals(t)) stack.push(a.add(b));
                else if ("-".equals(t)) stack.push(a.subtract(b));
                else if ("*".equals(t)) stack.push(a.multiply(b));
                else stack.push(a.divide(b, 10, RoundingMode.HALF_UP));
            } else {
                stack.push(new BigDecimal(t));
            }
        }
        return stack.empty() ? BigDecimal.ZERO : stack.pop();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
